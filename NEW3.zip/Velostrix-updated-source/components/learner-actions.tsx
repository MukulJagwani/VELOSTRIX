'use client';
import {useState} from 'react';
export function LearnerAction({endpoint,body={},children,redirect,className='vx-button'}:{endpoint:string;body?:Record<string,unknown>;children:React.ReactNode;redirect?:string;className?:string}){
 const [busy,setBusy]=useState(false),[error,setError]=useState(''),[message,setMessage]=useState('');
 async function act(){setBusy(true);setError('');try{const response=await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const data=await response.json() as {error?:string;message?:string;redirect?:string};if(!response.ok)throw new Error(data.error||'Please try again.');const next=data.redirect||redirect;if(next){window.location.assign(next);return}setMessage(data.message||'Saved.');}catch(cause){setError(cause instanceof Error?cause.message:'Please try again.')}finally{setBusy(false)}}
 return <div className="vx-action-control"><button className={className} disabled={busy||!!message} onClick={act}>{busy?'Please wait…':message?'Saved':children}</button>{error&&<p className="vx-form-error" role="alert">{error}</p>}{message&&<p role="status">{message}</p>}</div>;
}
export function PrintCertificate(){return <button className="vx-button vx-print-action" onClick={()=>window.print()}>Print / save as PDF</button>}
