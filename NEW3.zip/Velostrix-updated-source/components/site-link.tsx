import type {ComponentPropsWithRef} from 'react';

// Native navigation avoids the installed Vinext build's broken RSC-prefetch
// callback. Keep normal browser history, modifier-clicks, fragments and refs.
export default function SiteLink(props:ComponentPropsWithRef<'a'>){
 return <a {...props}/>;
}
