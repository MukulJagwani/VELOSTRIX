import Image from 'next/image';
import { Clock3, Mail, MapPin, Phone } from 'lucide-react';
import { company } from '@/lib/content';
import { whatsappHref } from '@/lib/contact';

export function InstagramLink() {
  return <a className="vx-contact-link vx-social" href={company.instagram} target="_blank" rel="noopener noreferrer"><Image unoptimized className="vx-social-icon" src="/icons/instagram.svg" alt="" width="20" height="20" /><span>Instagram · @velostrixsecurity</span></a>;
}

export function EmailLink() { return <a className="vx-contact-link vx-contact-email" href={`mailto:${company.email}`}><Mail size={20} aria-hidden="true" /><span>{company.email}</span></a>; }
export function LocationLink() { return <a className="vx-contact-link" href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(company.location)}`} target="_blank" rel="noopener noreferrer"><MapPin size={20} aria-hidden="true" /><span>{company.location}</span></a>; }
export function HoursDetail() { return <p className="vx-contact-link"><Clock3 size={20} aria-hidden="true" /><span>{company.hours}<br />Sunday closed</span></p>; }
export function PhoneLink() { return company.phone ? <a className="vx-contact-link" href={`tel:${company.phone.replace(/[^+\d]/g, '')}`}><Phone size={20} aria-hidden="true" /><span>{company.phone}</span></a> : null; }
export function WhatsAppLink() {
  const href = whatsappHref(company.phone);
  return href ? <a className="vx-contact-link" href={href} target="_blank" rel="noopener noreferrer"><Image unoptimized className="vx-social-icon" src="/icons/whatsapp.svg" alt="" width="20" height="20" /><span>Chat on WhatsApp</span></a> : null;
}
export function FloatingWhatsApp() {
  const href = whatsappHref(company.phone);
  if (!href) return null;
  return <a className="vx-whatsapp-float" href={href} target="_blank" rel="noopener noreferrer" aria-label="Chat with us on WhatsApp (opens in a new tab)"><Image unoptimized src="/icons/whatsapp.svg" alt="" width="28" height="28" /><span className="vx-whatsapp-tooltip" role="tooltip">Chat with us on WhatsApp</span></a>;
}
