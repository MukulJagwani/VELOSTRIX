import Image from 'next/image';
import { BookOpen, Terminal, LockKeyhole, Award, TrendingUp } from 'lucide-react';

const stages = [
  { name: 'Learn', icon: BookOpen, description: 'Build security foundations.' },
  { name: 'Practice', icon: Terminal, description: 'Work through authorised labs.' },
  { name: 'Secure', icon: LockKeyhole, description: 'Investigate, defend and report.' },
  { name: 'Certify', icon: Award, description: 'Complete your capstone and earn the Velostrix Certificate of Completion.' },
  { name: 'Advance', icon: TrendingUp, description: 'Present your portfolio and prepare for your next step.' },
];

export function LearningJourney({ compact = false }: { compact?: boolean }) {
  return <div className={`vx-learning-journey${compact ? ' vx-journey-compact' : ''}`}>
    <Image unoptimized className="vx-journey-art" src="/security-learning-journey.webp" alt="An illustrated cybersecurity learning workspace connecting practical laptop exercises with network investigation and defensive monitoring" width="1200" height="800" loading="lazy" />
    {!compact && <div className="vx-journey-caption"><h3>From understanding to confident practice.</h3><p>Each stage builds on the last. Make your progress visible through practical work in Cyber & AI Security.</p></div>}
    <ol className="vx-journey-steps" aria-label="The bootcamp learning journey">{stages.map(stage => <li key={stage.name}><span className="vx-journey-step-icon"><stage.icon size={22} aria-hidden="true" /></span><div><h4>{stage.name}</h4><p>{stage.description}</p></div></li>)}</ol>
  </div>;
}
