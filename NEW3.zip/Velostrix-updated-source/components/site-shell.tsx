import Link from '@/components/site-link';
import {Header,Footer} from './site-chrome';
import {FloatingWhatsApp} from './contact-details';
export function SiteShell({children}:{children:React.ReactNode}){return <div className="vx-site"><Header/><main id="main">{children}</main><Footer/><FloatingWhatsApp/></div>}
export function PageIntro({kicker,title,description}:{kicker:string;title:string;description:string}){return <div className="vx-page-intro"><Link className="vx-breadcrumb" href="/">Home</Link><span className="vx-kicker">{kicker}</span><h1>{title}</h1><p>{description}</p></div>}
