'use client';
import Link from '@/components/site-link';
import { BrainCircuit, GraduationCap, Network, ScanLine, Terminal, Fingerprint } from 'lucide-react';
import { cybersecurityCourses as courses, aiCourseCategories, courseEnquiryHref, courseHref, type Course } from '@/lib/courses';
import {Tabs,TabsList,TabsTrigger,TabsContent} from './ui/tabs';

const icons = { network: Network, terminal: Terminal, ethical: Fingerprint, testing: ScanLine, ai: BrainCircuit, master: GraduationCap };
export function CourseIcon({ course, size = 24 }: { course: Course; size?: number }) {
  const Icon = icons[course.icon];
  return <Icon size={size} aria-hidden="true" />;
}

export function CourseCatalogue({initialCategory='cybersecurity'}:{initialCategory?:string}) {
 return <Tabs defaultValue={initialCategory==='ai'?'ai':'cybersecurity'} className="vx-course-tabs"><TabsList aria-label="Course categories" className="vx-category-tabs"><TabsTrigger value="ai"><BrainCircuit size={19} aria-hidden="true"/>Artificial Intelligence</TabsTrigger><TabsTrigger value="cybersecurity"><Fingerprint size={19} aria-hidden="true"/>Cybersecurity</TabsTrigger></TabsList><TabsContent value="ai"><div className="vx-panel vx-category-intro"><span className="vx-kicker">ARTIFICIAL INTELLIGENCE</span><h2>Explore your AI learning direction.</h2><p>Discover learning areas from AI fundamentals to responsible innovation. Individual course details are coming soon.</p></div><div className="vx-category-grid">{aiCourseCategories.map(category=><article key={category.id} id={category.id} className="vx-category-card"><span className="vx-course-icon"><BrainCircuit aria-hidden="true"/></span><h3>{category.name}</h3><p>{category.description}</p><span className="vx-availability">Course details coming soon</span><Link className="vx-text-link" href="/certifications/ai">Explore AI certifications</Link></article>)}</div></TabsContent><TabsContent value="cybersecurity"><CybersecurityCourses/></TabsContent></Tabs>;
}

function CybersecurityCourses() {
  const flagship = courses.find(course => course.featured)!;
  return <>
    <nav className="vx-course-index" aria-label="Jump to a course">
      {courses.map(course => <a key={course.id} href={courseHref(course)}>{course.name}</a>)}
    </nav>
    <section className="vx-master-course" id={flagship.id} aria-labelledby="master-course-title">
      <div className="vx-master-copy">
        <span className="vx-kicker"><CourseIcon course={flagship} /> {flagship.category}</span>
        <h2 id="master-course-title">{flagship.name}</h2>
        <p>{flagship.description}</p>
        <strong className="vx-training-note">75% Practical Training · 25% Theory</strong>
        <div className="vx-course-actions"><a className="vx-button" href={courseEnquiryHref(flagship)}>Enquire now<span className="sr-only"> about {flagship.name}</span></a></div>
      </div>
      <div className="vx-training-balance" aria-label="Training balance: 75 percent practical training, 25 percent theory">
        <span className="vx-balance-label">LEARN THROUGH PRACTICE</span>
        <div className="vx-balance-numbers"><div><strong>75<span>%</span></strong><p>Practical training</p></div><div><strong>25<span>%</span></strong><p>Theory</p></div></div>
        <div className="vx-balance-track" aria-hidden="true"><span /><span /></div>
        <p>Build understanding. Put it to work.</p>
      </div>
    </section>
    <section className="vx-course-grid" aria-label="Explore individual courses">
      {courses.filter(course => !course.featured).map(course => <article className={`vx-course-card${course.free?' vx-free-course':''}`} id={course.id} key={course.id} aria-labelledby={`${course.id}-title`}>
        <div className="vx-course-heading"><span className="vx-course-icon"><CourseIcon course={course} size={27} /></span><span className="vx-kicker">{course.category}</span></div>
        {course.free&&<span className="vx-free-badge">FREE COURSE</span>}<h2 id={`${course.id}-title`}>{course.name}</h2><p>{course.description}</p>
        {course.topics.length > 0 && <div className="vx-course-modules"><h3>{course.id === 'penetration-testing' ? 'Specialisations' : 'Learning areas'}</h3><ul>{course.topics.map(topic => <li key={topic}>{topic}</li>)}</ul></div>}
        {course.note && <p className="vx-course-note">{course.note}</p>}
        <div className="vx-course-actions">{course.free?<Link className="vx-button" href="/learner/courses/cyber-law">Enroll free</Link>:<a className="vx-button vx-outline" href={courseEnquiryHref(course)}>Enquire now<span className="sr-only"> about {course.name}</span></a>}</div>
      </article>)}
    </section>
    <aside className="vx-panel vx-course-existing"><div><span className="vx-kicker">ALREADY EXPLORING OUR BOOTCAMP?</span><h2>Continue your Cyber & AI Security journey.</h2><p>Find the existing 12-week bootcamp curriculum, programme fee and founding-cohort details.</p></div><Link className="vx-button vx-outline" href="/bootcamp">View bootcamp details</Link></aside>
  </>;
}
