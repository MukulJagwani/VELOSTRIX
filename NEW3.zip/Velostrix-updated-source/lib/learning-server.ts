import {db,HttpError} from './server';
import {approvedCertificationCatalogue} from './certification-seed';
import {certificationCategories,certificationCategory,validDomain,type Certification,type CertificationDomain} from './certifications';
import {cyberLawLessons,cyberLawPassScore,cyberLawQuestions,cyberLawVersion} from './cyber-law';
import type {Learner} from './learner-auth';

export async function getCertifications(domain?:CertificationDomain,includeDraft=false){
 const overrides=await db().prepare('SELECT id,title,domain,category_id,description,level,issuer,source_url,kind,status,display_order,authorization_confirmed,updated_at FROM certifications').all<Certification>();
 const records=new Map(approvedCertificationCatalogue.map(item=>[item.id,item]));
 for(const item of overrides.results)records.set(item.id,item);
 return [...records.values()].filter(item=>(!domain||item.domain===domain)&&(includeDraft||(item.status==='published'&&item.authorization_confirmed===1))).sort((a,b)=>a.display_order-b.display_order||a.title.localeCompare(b.title));
}
export type Enrollment={id:string;course_id:string;content_version:string;status:string;created_at:string;completed_at:string|null};
export type CompletionCertificate={id:string;course_id:string;content_version:string;learner_name:string;issued_at:string};
export async function learnerDashboardData(learner:Learner){
 const [enrollments,interests,certificates]=await Promise.all([
  db().prepare('SELECT id,course_id,content_version,status,created_at,completed_at FROM course_enrollments WHERE learner_id=? ORDER BY created_at DESC').bind(learner.id).all<Enrollment>(),
  db().prepare('SELECT category_id,certification_id,created_at FROM certification_interests WHERE learner_id=? ORDER BY created_at DESC').bind(learner.id).all<{category_id:string;certification_id:string;created_at:string}>(),
  db().prepare('SELECT id,course_id,content_version,learner_name,issued_at FROM completion_certificates WHERE learner_id=? ORDER BY issued_at DESC').bind(learner.id).all<CompletionCertificate>(),
 ]);return {learner,enrollments:enrollments.results,interests:interests.results,certificates:certificates.results};
}
export async function cyberLawProgress(learnerId:string){
 const [enrollment,lessons,certificate]=await Promise.all([
  db().prepare("SELECT id,course_id,content_version,status,created_at,completed_at FROM course_enrollments WHERE learner_id=? AND course_id='cyber-law'").bind(learnerId).first<Enrollment>(),
  db().prepare("SELECT lesson_id FROM lesson_progress WHERE learner_id=? AND course_id='cyber-law'").bind(learnerId).all<{lesson_id:string}>(),
  db().prepare("SELECT id,course_id,content_version,learner_name,issued_at FROM completion_certificates WHERE learner_id=? AND course_id='cyber-law'").bind(learnerId).first<CompletionCertificate>(),
 ]);return {enrollment,completed:lessons.results.map(row=>row.lesson_id),certificate};
}
export async function enrolCyberLaw(learner:Learner){
 await db().prepare("INSERT INTO course_enrollments (id,learner_id,course_id,content_version,status,created_at) VALUES (?,?,'cyber-law',?,'enrolled',?) ON CONFLICT(learner_id,course_id) DO NOTHING").bind(crypto.randomUUID(),learner.id,cyberLawVersion,new Date().toISOString()).run();
 return {ok:true,redirect:'/learner/courses/cyber-law'};
}
export async function completeCyberLawLesson(learner:Learner,lessonId:unknown){
 const position=cyberLawLessons.findIndex(lesson=>lesson.id===lessonId);if(position<0)throw new HttpError(400,'Choose an available lesson.');
 const state=await cyberLawProgress(learner.id);
 if(!state.enrollment||state.enrollment.content_version!==cyberLawVersion)throw new HttpError(409,'Enrol in this course before recording progress.');
 if(cyberLawLessons.slice(0,position).some(lesson=>!state.completed.includes(lesson.id)))throw new HttpError(409,'Complete the earlier lessons first.');
 await db().prepare("INSERT INTO lesson_progress (id,learner_id,course_id,lesson_id,completed_at) VALUES (?,?,'cyber-law',?,?) ON CONFLICT(learner_id,course_id,lesson_id) DO NOTHING").bind(crypto.randomUUID(),learner.id,lessonId,new Date().toISOString()).run();
 return {ok:true,completed:[...new Set([...state.completed,String(lessonId)])]};
}
const answerKey=[1,2,0,1,2,1];
export async function assessCyberLaw(learner:Learner,answers:unknown){
 if(!Array.isArray(answers)||answers.length!==cyberLawQuestions.length||answers.some(value=>!Number.isInteger(value)||value<0||value>2))throw new HttpError(400,'Answer every question before submitting.');
 const state=await cyberLawProgress(learner.id);
 if(!state.enrollment||state.enrollment.content_version!==cyberLawVersion||cyberLawLessons.some(lesson=>!state.completed.includes(lesson.id)))throw new HttpError(409,'Complete every lesson before taking the knowledge check.');
 const score=answers.reduce((total,value,index)=>total+(value===answerKey[index]?1:0),0),passed=score>=cyberLawPassScore,now=new Date().toISOString();
 const statements=[db().prepare("INSERT INTO learner_assessments (id,learner_id,course_id,score,passed,created_at) VALUES (?,?,'cyber-law',?,?,?)").bind(crypto.randomUUID(),learner.id,score,passed?1:0,now)];
 if(passed){statements.push(db().prepare("INSERT INTO completion_certificates (id,learner_id,course_id,content_version,learner_name,issued_at) VALUES (?,?,'cyber-law',?,?,?) ON CONFLICT(learner_id,course_id) DO NOTHING").bind(crypto.randomUUID(),learner.id,cyberLawVersion,learner.name,now));statements.push(db().prepare("UPDATE course_enrollments SET status='completed',completed_at=COALESCE(completed_at,?) WHERE learner_id=? AND course_id='cyber-law'").bind(now,learner.id));}
 await db().batch(statements);const next=await cyberLawProgress(learner.id);
 return {ok:true,score,total:cyberLawQuestions.length,passed,certificate:next.certificate};
}
export async function saveCertificationInterest(learner:Learner,input:Record<string,unknown>){
 const category=certificationCategory(String(input.categoryId||''));if(!category)throw new HttpError(400,'Choose a certification category.');
 const certificationId=typeof input.certificationId==='string'?input.certificationId:'';
 if(certificationId){const records=await getCertifications(category.domain);if(!records.some(item=>item.id===certificationId&&item.category_id===category.id))throw new HttpError(400,'That certification is not available.');}
 await db().prepare('INSERT INTO certification_interests (id,learner_id,category_id,certification_id,created_at) VALUES (?,?,?,?,?) ON CONFLICT(learner_id,category_id,certification_id) DO NOTHING').bind(crypto.randomUUID(),learner.id,category.id,certificationId,new Date().toISOString()).run();
 return {ok:true,message:'Your interest is saved. The Velostrix team can help you with the next steps.'};
}
export async function adminLearningData(){
 const [learners,enrollments,interests,certificates]=await Promise.all([
  db().prepare('SELECT id,name,email,status,email_verified_at,created_at,last_login_at FROM learners ORDER BY created_at DESC').all<Learner>(),
  db().prepare('SELECT id,learner_id,course_id,status,created_at,completed_at FROM course_enrollments ORDER BY created_at DESC').all(),
  db().prepare('SELECT id,learner_id,category_id,certification_id,created_at FROM certification_interests ORDER BY created_at DESC').all(),
  db().prepare('SELECT id,learner_id,course_id,issued_at FROM completion_certificates ORDER BY issued_at DESC').all(),
 ]);return {learners:learners.results,enrollments:enrollments.results,interests:interests.results,certificates:certificates.results,catalogue:await getCertifications(undefined,true),categories:certificationCategories};
}
export async function saveCertificationRecord(input:Record<string,unknown>,adminEmail:string){
 const clean=(key:string,max:number)=>{const value=typeof input[key]==='string'?input[key].trim():'';if(value.length>max)throw new HttpError(400,`${key} is too long.`);return value};
 const id=clean('id',100)||crypto.randomUUID();if(!/^[a-z0-9][a-z0-9-]{1,99}$/.test(id))throw new HttpError(400,'Invalid certification identifier.');
 const title=clean('title',180),description=clean('description',800),domain=input.domain,categoryId=clean('category_id',80),category=certificationCategory(categoryId);
 if(title.length<2||description.length<10||!validDomain(domain)||category?.domain!==domain)throw new HttpError(400,'Add a title, description and matching category.');
 const level=clean('level',20)||null;if(level&&!['Beginner','Intermediate','Advanced'].includes(level))throw new HttpError(400,'Choose a valid level.');
 const status=input.status==='published'?'published':'draft',confirmed=input.authorization_confirmed===true||input.authorization_confirmed===1;
 if(status==='published'&&!confirmed)throw new HttpError(400,'Confirm the right to promote this offering and the accuracy of its details before publishing.');
 const order=Number(input.display_order||0);if(!Number.isInteger(order)||order<0||order>100000)throw new HttpError(400,'Display order must be a non-negative whole number.');
 const source=clean('source_url',500)||null;if(source){try{if(new URL(source).protocol!=='https:')throw new Error()}catch{throw new HttpError(400,'Use an HTTPS source URL.')}}
 await db().prepare('INSERT INTO certifications (id,title,domain,category_id,description,level,issuer,source_url,kind,status,display_order,authorization_confirmed,updated_at,updated_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET title=excluded.title,domain=excluded.domain,category_id=excluded.category_id,description=excluded.description,level=excluded.level,issuer=excluded.issuer,source_url=excluded.source_url,kind=excluded.kind,status=excluded.status,display_order=excluded.display_order,authorization_confirmed=excluded.authorization_confirmed,updated_at=excluded.updated_at,updated_by=excluded.updated_by').bind(id,title,domain,categoryId,description,level,clean('issuer',100)||null,source,input.kind==='pathway'?'pathway':'certification',status,order,confirmed?1:0,new Date().toISOString(),adminEmail).run();
 return {ok:true,id};
}
