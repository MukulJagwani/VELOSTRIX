import {randomBytes,scrypt,timingSafeEqual} from 'node:crypto';
const settings={N:32768,r:8,p:3,maxmem:64*1024*1024};
function derive(password:string,salt:Buffer){return new Promise<Buffer>((resolve,reject)=>scrypt(password,salt,32,settings,(error,key)=>error?reject(error):resolve(key)))}
export function validPassword(password:unknown):password is string{return typeof password==='string'&&password.length>=15&&password.length<=128}
export async function hashPassword(password:string){const salt=randomBytes(16);const key=await derive(password,salt);return `scrypt-v1$32768$8$3$${salt.toString('hex')}$${key.toString('hex')}`}
export async function verifyPassword(password:string,encoded:string){
 const parts=encoded.split('$');
 if(parts.length!==6||parts.slice(0,4).join('$')!=='scrypt-v1$32768$8$3'||!/^[a-f0-9]{32}$/.test(parts[4])||!/^[a-f0-9]{64}$/.test(parts[5]))return false;
 const actual=await derive(password,Buffer.from(parts[4],'hex'));
 return timingSafeEqual(actual,Buffer.from(parts[5],'hex'));
}
// A well-formed non-account hash ensures an unknown email still performs scrypt.
export const dummyPasswordHash='scrypt-v1$32768$8$3$00000000000000000000000000000000$'+'00'.repeat(32);
