export const segments = ["Student / recent graduate","Career switcher","Working IT professional"] as const;
export const statuses = ["New","Contacted","Approved","Rejected"] as const;
export const policyLabels:Record<string,string> = {privacy:"Privacy Policy",terms:"Terms & Conditions",refund:"Refund & Cancellation Policy"};
export type Application = {id:string;name:string;email:string;phone:string;segment:string;location:string;course:string;status:string;payment_status:string;payment_id:string|null;payment_url:string|null;payment_attempt:string|null;notification_status:string;created_at:string;updated_at:string};
export const enquiryStatuses=["New","Contacted","Call scheduled","Closed"] as const;
export type Enquiry={id:string;name:string;email:string;phone:string;location:string;course:string;request_type:'callback'|'quote';preferred_time:string;message:string;status:string;scheduled_at:string|null;admin_note:string;notification_status:string;created_at:string;updated_at:string};
export type Policy = {slug:string;label:string;file_name:string;updated_at:string};
export const tuition = 4999900;
