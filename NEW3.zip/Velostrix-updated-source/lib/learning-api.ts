import {admin,body,db,HttpError,json} from './server';
import {apiLearner,authRateLimit,learnerAuthAction,readLearner} from './learner-auth';
import {adminLearningData,assessCyberLaw,completeCyberLawLesson,enrolCyberLaw,getCertifications,learnerDashboardData,saveCertificationInterest,saveCertificationRecord} from './learning-server';
import {validDomain,type CertificationDomain} from './certifications';
async function jsonBody(req:Request){if(!req.headers.get('content-type')?.toLowerCase().startsWith('application/json'))throw new HttpError(415,'Send this request as JSON.');const input=await body(req);if(!input||Array.isArray(input)||typeof input!=='object')throw new HttpError(400,'Invalid request.');return input as Record<string,unknown>}
export async function learningApi(req:Request,path:string):Promise<Response|null>{
 if(path.startsWith('auth/')&&req.method==='POST')return learnerAuthAction(req,path.slice(5),await jsonBody(req));
 if(path==='auth/session'&&req.method==='GET')return json({learner:await readLearner(req.headers)});
 if(path==='certifications'&&req.method==='GET'){const domain=new URL(req.url).searchParams.get('domain');if(domain&&!validDomain(domain))throw new HttpError(400,'Choose AI or cybersecurity.');return json({certifications:await getCertifications((domain||undefined) as CertificationDomain|undefined)})}
 if(path.startsWith('learner/')){
  const learner=await apiLearner(req);
  if(path==='learner/dashboard'&&req.method==='GET')return json(await learnerDashboardData(learner));
  if(req.method==='POST'){
   const input=await jsonBody(req);await authRateLimit(req,'learner-action',learner.id,100,60);
   if(path==='learner/enroll'){
    if(input.courseId!=='cyber-law')throw new HttpError(400,'Choose an available free course.');return json(await enrolCyberLaw(learner),201);
   }
   if(path==='learner/lesson')return json(await completeCyberLawLesson(learner,input.lessonId));
   if(path==='learner/assessment'){await authRateLimit(req,'assessment',learner.id,10,5);return json(await assessCyberLaw(learner,input.answers));}
   if(path==='learner/interests')return json(await saveCertificationInterest(learner,input),201);
  }
  throw new HttpError(404,'Learner action not found.');
 }
 if(path==='admin/learning'&&req.method==='GET'){await admin();return json(await adminLearningData())}
 if(path==='admin/certifications'&&req.method==='POST'){const owner=await admin();return json(await saveCertificationRecord(await jsonBody(req),owner.email))}
 const account=path.match(/^admin\/learners\/([a-f0-9-]{36})$/);
 if(account&&req.method==='PATCH'){
  await admin();const input=await jsonBody(req);if(input.status!=='active'&&input.status!=='suspended')throw new HttpError(400,'Choose an account status.');
  const result=await db().batch([db().prepare('UPDATE learners SET status=? WHERE id=? RETURNING id').bind(input.status,account[1]),db().prepare('DELETE FROM learner_sessions WHERE learner_id=?').bind(account[1])]);if(!result[0].results.length)throw new HttpError(404,'Learner not found.');return json({ok:true});
 }
 return null;
}
