import { env } from "cloudflare:workers";
import { getChatGPTUser } from "@/app/chatgpt-auth";
import { segments, tuition, type Application, type Enquiry } from "./domain";
import { company } from "./content";
import {isAvailableCourse,hasConfiguredCourseFee} from "./courses";
export function db() { if(!env.DB) throw new Error("Database unavailable"); return env.DB; }
export function bucket() { if(!env.BUCKET) throw new Error("Document storage unavailable"); return env.BUCKET; }
export function config(key:string) { return String((env as unknown as Record<string,unknown>)[key] || ""); }
export class HttpError extends Error { constructor(public status:number,message:string){super(message)} }
export function json(data:unknown,status=200) { return Response.json(data,{status,headers:{"Cache-Control":"no-store","X-Content-Type-Options":"nosniff"}}); }
export async function isAdmin(){ const user=await getChatGPTUser(); const allowed=config("ADMIN_EMAILS").toLowerCase().split(",").map(x=>x.trim()).filter(Boolean); return user && allowed.includes(user.email.toLowerCase()) ? user : null; }
export async function admin(){const user=await isAdmin(); if(!user) throw new HttpError(403,"Please sign in with the authorised admin account."); return user;}
export function sameOrigin(req:Request){ const origin=req.headers.get("origin"); if(!origin || origin!==new URL(req.url).origin) throw new HttpError(403,"Please submit from the Velostrix website."); }
export async function body(req:Request,max=12000){if(Number(req.headers.get("content-length")||0)>max)throw new HttpError(413,"Request is too large."); const raw=await req.text(); if(raw.length>max)throw new HttpError(413,"Request is too large."); try{return JSON.parse(raw)}catch{throw new HttpError(400,"Invalid request.")}}
export function validateApplication(input:unknown){
 const x=input as Record<string,unknown>;
 if(!x || typeof x!=="object")throw new HttpError(400,"Please complete all required fields.");
 const clean=(key:string)=>typeof x[key]==="string" ? String(x[key]).trim() : "";
 const name=clean("name"),email=clean("email").toLowerCase(),phone=clean("phone"),segment=clean("segment")||"Not specified",location=clean("location"),course=clean("course");
 if(name.length<2||name.length>100)throw new HttpError(400,"Enter your full name (2–100 characters).");
 if(email.length>254||!/^\S+@\S+\.\S+$/.test(email))throw new HttpError(400,"Enter a valid email address.");
 if(!/^[+\d\s()\-]{7,25}$/.test(phone)||phone.replace(/\D/g,"").length<7)throw new HttpError(400,"Enter a valid phone or WhatsApp number.");
 if(segment!=="Not specified"&&!(segments as readonly string[]).includes(segment))throw new HttpError(400,"Choose the option that describes you.");
 if(location.length<2||location.length>120)throw new HttpError(400,"Enter your city or location (2–120 characters).");
 if(!isAvailableCourse(course))throw new HttpError(400,"Choose an available course.");
 return {name,email,phone,segment,location,course};
}
export async function rateLimit(req:Request){
 const ip=req.headers.get("cf-connecting-ip") || "local";
 const hour=Math.floor(Date.now()/3600000);
 const hash=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(ip+":"+hour));
 const key=Array.from(new Uint8Array(hash)).map(x=>x.toString(16).padStart(2,"0")).join("");
 const result=await db().prepare("INSERT INTO submission_limits (key,count,expires_at) VALUES (?,1,?) ON CONFLICT(key) DO UPDATE SET count=count+1 RETURNING count").bind(key,(hour+2)*3600000).first<{count:number}>();
 if((result?.count||0)>8)throw new HttpError(429,"Too many submissions. Please try again later or email us.");
 await db().prepare("DELETE FROM submission_limits WHERE expires_at < ?").bind(Date.now()).run();
}
export function connections(){return {payments:!!(config("RAZORPAY_KEY_ID")&&config("RAZORPAY_KEY_SECRET")&&config("RAZORPAY_WEBHOOK_SECRET")),email:!!(config("RESEND_API_KEY")&&config("EMAIL_FROM")),webhook:config("SITE_URL")+"/api/webhooks/razorpay"};}
export async function notifyApplication(a:Application){
 if(!connections().email)return "Not configured";
 try {
 const r=await fetch("https://api.resend.com/emails",{method:"POST",headers:{"Authorization":"Bearer "+config("RESEND_API_KEY"),"Content-Type":"application/json","Idempotency-Key":"application-"+a.id},body:JSON.stringify({from:config("EMAIL_FROM"),to:[config("CONTACT_EMAIL")||company.email],subject:"New Velostrix application",text:["A new course application has arrived.",a.name,a.email,a.phone,a.location,a.course,a.segment,"Review it: "+config("SITE_URL")+"/admin"].join("\n")}),signal:AbortSignal.timeout(12000)});
 return r.ok?"Sent":"Failed";
 }catch{return "Failed"}
}
export async function notifyEnquiry(a:Enquiry){
 if(!connections().email)return "Not configured";
 try{const r=await fetch("https://api.resend.com/emails",{method:"POST",headers:{"Authorization":"Bearer "+config("RESEND_API_KEY"),"Content-Type":"application/json","Idempotency-Key":"enquiry-"+a.id},body:JSON.stringify({from:config("EMAIL_FROM"),to:[config("CONTACT_EMAIL")||company.email],subject:"Velostrix: new "+(a.request_type==='callback'?'counselling callback':'fee quote')+" request",text:[a.name,a.email,a.phone,a.location,a.course,"Preferred time: "+a.preferred_time,a.message,"Review: "+config("SITE_URL")+"/admin"].join("\n")}),signal:AbortSignal.timeout(12000)});return r.ok?"Sent":"Failed"}catch{return "Failed"}
}
type RazorpayPaymentLink={id:string;reference_id:string;amount:number;amount_paid:number;currency:string;short_url:string;status:string};
type RazorpayResponse=Partial<RazorpayPaymentLink>&{payment_links?:RazorpayPaymentLink[]};
export async function razorpay(path:string,init:RequestInit={}){
 if(!connections().payments)throw new HttpError(503,"Connect Razorpay before creating payment links.");
 const response=await fetch("https://api.razorpay.com/v1"+path,{...init,headers:{"Authorization":"Basic "+btoa(config("RAZORPAY_KEY_ID")+":"+config("RAZORPAY_KEY_SECRET")),"Content-Type":"application/json"},signal:AbortSignal.timeout(15000)});
 if(!response.ok)throw new HttpError(502,"Razorpay could not complete the request. Please try again.");
 return response.json() as Promise<RazorpayResponse>;
}
export async function createPayment(id:string){
 const a=await db().prepare("SELECT * FROM applications WHERE id=?").bind(id).first<Application>();
 if(!a)throw new HttpError(404,"Application not found.");
 if(!hasConfiguredCourseFee(a.course))throw new HttpError(409,"The fee for this course has not been configured. Contact the team before requesting payment.");
 if(a.payment_status==="Paid")throw new HttpError(409,"This application is already paid.");
 if(a.status!=="Approved")throw new HttpError(409,"Approve the application before creating a payment link.");
 if(a.payment_url)return {url:a.payment_url};
 if(!connections().payments)throw new HttpError(503,"Connect Razorpay before creating payment links.");
 const reference="v_"+id.replace(/-/g,"");
 if(a.payment_attempt){
   const found=await razorpay("/payment_links/?reference_id="+encodeURIComponent(reference));
   const link=found.payment_links?.find(p=>p.reference_id===reference && p.amount===tuition && p.currency==="INR");
   if(link?.id && /^https:\/\//.test(link.short_url||"")){await db().prepare("UPDATE applications SET payment_id=?,payment_url=?,payment_status=CASE WHEN payment_status='Paid' THEN 'Paid' ELSE ? END,updated_at=? WHERE id=?").bind(link.id,link.short_url,link.status==="paid"&&link.amount_paid===tuition?"Paid":"Link ready",new Date().toISOString(),id).run();return {url:link.short_url};}
   throw new HttpError(409,"A payment request is being reconciled. Wait a moment and select Refresh payment link. Contact support if it persists.");
 }
 const claimed=await db().prepare("UPDATE applications SET payment_attempt=?,payment_status='Creating link' WHERE id=? AND payment_attempt IS NULL AND status='Approved' RETURNING id").bind(reference,id).first();
 if(!claimed)throw new HttpError(409,"Payment link creation is already in progress.");
 try{
 const link=await razorpay("/payment_links/",{method:"POST",body:JSON.stringify({amount:tuition,currency:"INR",accept_partial:false,reference_id:reference,description:"Velostrix Cyber & AI Security Bootcamp — 12 weeks",customer:{name:a.name,email:a.email,contact:a.phone.replace(/[^+\d]/g,"")},notify:{sms:false,email:false},reminder_enable:false,notes:{application_id:a.id}})});
 if(!link.id||!/^https:\/\//.test(link.short_url||""))throw new Error("Invalid gateway response");
 await db().prepare("UPDATE applications SET payment_id=?,payment_url=?,payment_status=CASE WHEN payment_status='Paid' THEN 'Paid' ELSE 'Link ready' END,updated_at=? WHERE id=?").bind(link.id,link.short_url,new Date().toISOString(),id).run();
 return {url:link.short_url};
 }catch(error){await db().prepare("UPDATE applications SET payment_status='Needs review' WHERE id=? AND payment_status!='Paid'").bind(id).run();throw error}
}
export async function paymentWebhook(req:Request){
 const secret=config("RAZORPAY_WEBHOOK_SECRET");if(!secret)throw new HttpError(503,"Webhook is not configured.");
 const raw=await req.text(); if(raw.length>200000)throw new HttpError(413,"Payload too large.");
 const signature=req.headers.get("x-razorpay-signature")||"";if(!/^[0-9a-f]{64}$/i.test(signature))throw new HttpError(401,"Invalid signature.");
 const key=await crypto.subtle.importKey("raw",new TextEncoder().encode(secret),{name:"HMAC",hash:"SHA-256"},false,["verify"]);
 const sig=Uint8Array.from(signature.match(/.{2}/g)!,x=>parseInt(x,16));
 if(!await crypto.subtle.verify("HMAC",key,sig,new TextEncoder().encode(raw)))throw new HttpError(401,"Invalid signature.");
 let event;try{event=JSON.parse(raw)}catch{throw new HttpError(400,"Invalid event");}
 if(event.event!=="payment_link.paid")return json({received:true});
 const link=event.payload?.payment_link?.entity;
 if(!link?.id || link.currency!=="INR" || link.amount!==tuition || link.amount_paid!==tuition || link.status!=="paid")throw new HttpError(400,"Payment does not match the program fee.");
 const eventId=req.headers.get("x-razorpay-event-id");if(!eventId)throw new HttpError(400,"Missing event id.");
 if(await db().prepare("SELECT id FROM webhook_events WHERE id=?").bind(eventId).first())return json({received:true});
 // A gateway event can arrive before the creation response; match the unique server-generated reference as well.
 const a=await db().prepare("SELECT id FROM applications WHERE payment_id=? OR payment_attempt=?").bind(link.id,link.reference_id||"").first<{id:string}>();
 if(!a)throw new HttpError(409,"Payment application is not available yet.");
 await db().batch([db().prepare("UPDATE applications SET payment_status='Paid',payment_id=?,updated_at=? WHERE id=?").bind(link.id,new Date().toISOString(),a.id),db().prepare("INSERT OR IGNORE INTO webhook_events (id,created_at) VALUES (?,?)").bind(eventId,new Date().toISOString())]);
 return json({received:true});
}
