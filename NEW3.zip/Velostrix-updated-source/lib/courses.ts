import { company } from './content';

export type Course = {
  id: string;
  name: string;
  category: string;
  domain: 'ai' | 'cybersecurity';
  description: string;
  topics: string[];
  icon: 'network' | 'terminal' | 'ethical' | 'testing' | 'ai' | 'master';
  featured?: boolean;
  free?: boolean;
  note?: string;
};

// Shared by the catalogue, navigation, search, enquiry forms and server validation.
// New courses have no configured price, duration or certification claims.
export const courses: Course[] = [
  {
    id: 'ccna-network-fundamentals', name: 'CCNA (Network Fundamentals)',
    domain: 'cybersecurity', category: 'NETWORKING', icon: 'network',
    description: 'Build a working understanding of the networks that connect people, systems and services.',
    topics: ['Networking fundamentals', 'Networking concepts and protocols', 'Network infrastructure', 'Foundational networking skills'],
  },
  {
    id: 'kali-linux', name: 'Kali Linux (Basics to Advanced)',
    domain: 'cybersecurity', category: 'LINUX & SECURITY', icon: 'terminal',
    description: 'Progress from Linux fundamentals to advanced Kali Linux usage through practical cybersecurity learning.',
    topics: ['Linux fundamentals', 'Kali Linux basics', 'Practical security workflows', 'Advanced usage in authorised lab environments'],
  },
  {
    id: 'ceh-ai-security', name: 'CEH V13 + AI Security (Ethical Hacking)',
    domain: 'cybersecurity', category: 'ETHICAL HACKING', icon: 'ethical',
    description: 'Explore ethical hacking and AI security with a focus on authorised testing, defensive learning and responsible practice.',
    topics: ['Mobile security testing', 'Wi-Fi security testing', 'Security camera / IoT security concepts', 'System security testing', 'Social engineering / social media security awareness', 'AI security'],
    note: 'All exercises are limited to systems you own or have explicit permission to assess. Training does not imply an external certification or accreditation.',
  },
  {
    id: 'penetration-testing', name: 'Penetration Testing',
    domain: 'cybersecurity', category: 'SECURITY ASSESSMENT', icon: 'testing',
    description: 'Develop a professional approach to authorised security assessment across connected systems and applications.',
    topics: ['Mobile Penetration Testing', 'Network Penetration Testing', 'Web Application Penetration Testing', 'Active Directory Penetration Testing', 'API Penetration Testing'],
    note: 'Specialisations within one course, focused on agreed scope, authorised assessment and defensive recommendations.',
  },
  {
    id: 'cloud-security', name: 'Cloud Security',
    domain: 'cybersecurity', category: 'CLOUD SECURITY', icon: 'network',
    description: 'Learn to protect cloud environments through secure architecture, identity controls, monitoring and responsible incident response.',
    topics: ['Cloud Security Fundamentals', 'Cloud Architecture & Shared Responsibility', 'Identity and Access Management', 'Cloud Network Security', 'Data Protection & Encryption', 'Cloud Security Monitoring', 'Threat Detection', 'Cloud Vulnerability Management', 'Cloud Incident Response', 'Cloud Compliance & Governance', 'Security Misconfiguration Awareness', 'AWS / Azure / GCP Security Concepts'],
    note: 'Vendor-neutral learning. No official AWS, Microsoft or Google certification affiliation is claimed.',
  },
  {
    id: 'cyber-law', name: 'Cyber Law', domain: 'cybersecurity', category: 'FREE COURSE', icon: 'ethical', free: true,
    description: 'Understand the legal and regulatory foundations that influence cyberspace, digital activities, privacy, cybercrime and responsible technology use.',
    topics: ['Introduction to Cyber Law', 'Cybercrime Fundamentals', 'Data Privacy Principles', 'Digital Evidence', 'Electronic Records', 'Online Fraud', 'Identity Theft', 'Intellectual Property in Digital Environments', 'Social Media & Digital Responsibility', 'Cybersecurity Legal Responsibilities', 'Ethical and Responsible Technology Use', 'Overview of relevant cyber regulations'],
    note: 'Complete the lessons and knowledge check to receive a Velostrix Certificate of Completion. This is an introductory learning course, not an accredited legal qualification.',
  },
  {
    id: 'cybersecurity-master-course', name: 'Cybersecurity Master Course',
    domain: 'cybersecurity', category: 'FLAGSHIP PROGRAMME', icon: 'master', featured: true,
    description: 'An intensive hands-on cybersecurity programme designed around 75% practical training and 25% theoretical learning.',
    topics: ['75% Practical Training', '25% Theory'],
  },
];

export const cybersecurityCourses = courses.filter(course => course.domain === 'cybersecurity');

export const courseOptions = [company.course, ...courses.filter(course=>!course.free).map(course => course.name)];
export function findCourse(id: string | undefined) { return courses.find(course => course.id === (id === 'claude-security' ? 'cloud-security' : id)); }
export function courseHref(course: Course) { return `/courses#${course.id}`; }
export function courseEnquiryHref(course: Course) { return `/contact?intent=callback&course=${encodeURIComponent(course.id)}`; }
export function isAvailableCourse(name: string) { return courseOptions.includes(name); }
export function hasConfiguredCourseFee(name: string) { return name === company.course; }

export const aiCourseCategories = [
  ['ai-fundamentals','AI Fundamentals','Build AI literacy and understand how intelligent systems work.'],
  ['generative-ai','Generative AI','Explore how generative tools create and transform content.'],
  ['prompt-engineering','Prompt Engineering','Develop clear instructions and evaluate model responses.'],
  ['ai-for-business','AI for Business','Connect AI capabilities with practical business needs.'],
  ['ai-security','AI Security','Explore the risks and defensive practices around AI systems.'],
  ['ai-development','AI Development','Discover the building blocks of AI-enabled applications.'],
  ['ai-automation','AI Automation','Explore responsible approaches to automating workflows.'],
  ['ai-data','AI & Data','Understand the relationship between data quality and AI outcomes.'],
  ['responsible-ai','Responsible AI','Consider privacy, fairness, accountability and human oversight.'],
].map(([id,name,description])=>({id,name,description}));
