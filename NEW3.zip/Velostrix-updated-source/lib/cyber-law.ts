export const cyberLawVersion = '1';
export const cyberLawPassScore = 5;
export const cyberLawLessons = [
 {id:'law-and-responsibility',title:'Cyber law & responsible technology use',areas:['Introduction to Cyber Law','Cybersecurity Legal Responsibilities','Overview of relevant cyber regulations'],paragraphs:[
  'Cyber law describes legal rules that affect digital activities, people, information and systems. These rules can address privacy, electronic transactions, intellectual property and harmful behaviour. The rules that apply depend on the location, activity, organisation and people involved.',
  'Responsible security work starts with permission. Before testing a system, obtain clear authorisation, agree the scope and document what activities are permitted. Access to a tool or an exposed system is not permission to assess it. Stop and ask when the scope is unclear.',
  'Organisations translate legal and contractual responsibilities into policies and procedures. Learn which reporting channel to use, how to handle confidential information and when to involve a qualified legal or security professional. This course introduces general principles; it does not determine what is lawful in a particular case.',
 ],source:['UNODC: The role of cybercrime law','https://sherloc.unodc.org/cld/en/education/tertiary/cybercrime/module-3/key-issues/the-role-of-cybercrime-law.html']},
 {id:'fraud-and-identity',title:'Cybercrime, online fraud & identity misuse',areas:['Cybercrime Fundamentals','Online Fraud','Identity Theft'],paragraphs:[
  'Digital systems can be targets of harmful activity or tools used to carry it out. Common warning signs include requests for passwords, unexpected payment changes, impersonation and messages that pressure you to act before checking.',
  'Identity information may be misused to impersonate a person or gain access to their accounts. Protect recovery codes and authentication secrets. Verify a sensitive request using a trusted contact route you already know, rather than the phone number or link contained in the suspicious message.',
  'If an incident is suspected, follow the organisation’s reporting process. Preserve the relevant message and context, avoid further interaction and involve the appropriate support team. Reporting procedures and legal duties differ by jurisdiction; do not assume one universal response deadline.',
 ],source:['UNODC: Computer-related offences','https://sherloc.unodc.org/cld/en/education/tertiary/cybercrime/module-2/key-issues/computer-related-offences.html']},
 {id:'privacy',title:'Data privacy principles',areas:['Data Privacy Principles','Ethical and Responsible Technology Use'],paragraphs:[
  'Privacy-aware work begins with a clear purpose. Collect information that is relevant to that purpose, explain its use appropriately and protect it throughout its lifecycle. Access should be limited to people who need it for their work.',
  'Think beyond collection. Consider accuracy, retention, access requests, onward sharing and secure disposal. A dataset that appears anonymous may still reveal people when combined with other information. AI tools require the same care: do not paste confidential or personal information into a tool without understanding the applicable policy and safeguards.',
  'Privacy principles guide responsible decisions, but do not replace jurisdiction-specific legal requirements. When a new use of data changes the original purpose or introduces uncertainty, consult the appropriate privacy or legal lead before proceeding.',
 ],source:['OECD: Privacy principles','https://www.oecd.org/en/topics/privacy-principles.html']},
 {id:'records-and-evidence',title:'Electronic records & digital evidence',areas:['Electronic Records','Digital Evidence'],paragraphs:[
  'Electronic records include messages, documents, logs and transaction histories. They can help explain what happened, but their significance depends on context, reliability and how they were obtained.',
  'Digital evidence requires careful handling. Preserve originals where possible, document the source and collection steps, limit changes, and maintain a record of who handled the material. A screenshot can provide context, but may omit metadata or other information needed for an investigation.',
  'Work within your authority and follow an approved preservation procedure. Do not investigate someone else’s account or device without authorisation. Whether material is admissible in a proceeding depends on applicable rules and facts; completing this lesson does not establish that a collection method is legally sufficient.',
 ],source:['UNODC: Digital evidence','https://sherloc.unodc.org/cld/en/education/tertiary/cybercrime/module-4/key-issues/digital-evidence.html']},
 {id:'intellectual-property',title:'Intellectual property in digital environments',areas:['Intellectual Property in Digital Environments'],paragraphs:[
  'Software, writing, images and other creative work may be protected by intellectual property rights. Being able to find or download a work online does not automatically give permission to copy, redistribute or commercially reuse it.',
  'Check the licence or obtain appropriate permission. Licence conditions may address attribution, modification, redistribution or commercial use. Keep a record of permissions and the version of the licence you relied on. Different types of intellectual property have different rules.',
  'AI-generated and AI-assisted content can raise questions about source material, rights and permitted use. Review the relevant tool terms, organisational policy and the material itself. Seek qualified guidance when ownership or permission is uncertain.',
 ],source:['WIPO: Copyright questions','https://www.wipo.int/en/web/copyright/faq-copyright']},
 {id:'digital-citizenship',title:'Social media & digital responsibility',areas:['Social Media & Digital Responsibility','Ethical and Responsible Technology Use'],paragraphs:[
  'Responsible participation online includes respecting other people’s privacy, checking information before sharing it and considering how a post could affect an individual or organisation. Public access to someone’s information does not remove the need for care.',
  'Pause before sharing screenshots, contact details, workplace information or allegations. Check the source, audience and context. Use the platform’s reporting tools and your organisation’s escalation process when you encounter harmful activity.',
  'Bring the lessons together: obtain permission, handle information carefully, respect rights and document decisions. For a real legal or regulatory question, identify the relevant jurisdiction and involve a qualified professional. Responsible technology use is an ongoing practice.',
 ],source:['UNESCO: Digital citizenship education','https://www.unesco.org/en/articles/global-citizenship-education-digital-age-teacher-guidelines']},
];
// Correct answers remain in the server module; only questions/options reach the learner.
export const cyberLawQuestions = [
 {id:'scope',question:'Before assessing a system, what should you do?',options:['Assume public access means permission','Obtain authorisation and agree the scope','Test first and report afterwards']},
 {id:'fraud',question:'An unexpected message changes payment instructions. What is the appropriate next step?',options:['Pay quickly to avoid the stated deadline','Reply with your recovery code','Verify using an independently trusted contact route']},
 {id:'privacy',question:'Which approach supports privacy?',options:['Collect information for a clear purpose and limit access','Keep all data indefinitely','Share personal data whenever it is convenient']},
 {id:'evidence',question:'What supports reliable handling of digital evidence?',options:['Edit the original to make it easier to read','Preserve the material and document how it was handled','Assume every screenshot is automatically admissible']},
 {id:'rights',question:'Finding an image online means that…',options:['It is free for every use','Attribution always replaces permission','You should check the licence or obtain permission']},
 {id:'rules',question:'When a legal obligation is unclear, what should you do?',options:['Apply a rule from any country','Identify the relevant context and seek qualified guidance','Ignore organisational procedures']},
];
