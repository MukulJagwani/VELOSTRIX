/** One international-format business phone number powers phone and WhatsApp links. */
export function whatsappHref(phone: string) {
  const digits = phone.replace(/\D/g, '');
  return /^\+/.test(phone.trim()) && /^[1-9]\d{7,14}$/.test(digits) ? `https://wa.me/${digits}` : null;
}
