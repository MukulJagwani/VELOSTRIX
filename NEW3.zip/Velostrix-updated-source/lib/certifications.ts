export type CertificationDomain = 'ai' | 'cybersecurity';
export type CertificationLevel = 'Beginner' | 'Intermediate' | 'Advanced';
export type CertificationCategory = {id:string;name:string;description:string;domain:CertificationDomain};
export type Certification = {id:string;title:string;domain:CertificationDomain;category_id:string;description:string;level:CertificationLevel|null;issuer:string|null;source_url:string|null;kind:'certification'|'pathway';status:'draft'|'published';display_order:number;authorization_confirmed:number;updated_at:string};

const aiAreas = [
 ['ai-essentials','AI Essentials','Start building practical AI literacy and understand the foundations of modern artificial intelligence.'],
 ['ai-business','AI Business','Explore how AI can support strategy, operations, marketing, finance and decision-making.'],
 ['ai-executive','AI Executive','Connect AI opportunities with leadership, governance and informed strategic decisions.'],
 ['ai-security','AI Security','Understand the intersection of AI systems and modern cybersecurity.'],
 ['ai-cloud','AI Cloud','Explore cloud environments, AI infrastructure and modern cloud technologies.'],
 ['ai-development','AI Development','Develop a direction for building and working with AI-enabled applications.'],
 ['ai-specialization','AI Specialization','Discover focused areas of AI practice and emerging applications.'],
 ['ai-healthcare','AI Healthcare','Explore responsible AI applications in health-related environments.'],
 ['ai-data-robotics','AI Data & Robotics','Explore data, automation, intelligent systems and emerging technologies.'],
 ['ai-learning-education','AI Learning & Education','Consider how AI can support teaching, learning and educational workflows.'],
 ['ai-design-creative','AI Design & Creative','Explore AI-assisted creative processes with responsible human direction.'],
];
const securityAreas = [
 ['security-foundations','Security Foundations','Build a direction around networks, systems and security principles.'],
 ['ethical-hacking','Ethical Hacking','Explore authorised testing and defensive cybersecurity learning.'],
 ['penetration-testing','Penetration Testing','Explore professional assessment of applications, networks and connected systems.'],
 ['cloud-security','Cloud Security','Understand pathways focused on identity, architecture and protection in cloud environments.'],
 ['security-operations','Security Operations','Explore detection, investigation, response and security monitoring.'],
 ['governance-risk','Governance & Risk','Explore the relationship between security decisions, organisational risk and responsibility.'],
];
export const certificationCategories:CertificationCategory[] = [
 ...aiAreas.map(([id,name,description])=>({id,name,description,domain:'ai' as const})),
 ...securityAreas.map(([id,name,description])=>({id,name,description,domain:'cybersecurity' as const})),
];
export function certificationCategory(id:string){return certificationCategories.find(category=>category.id===id)}
export function validDomain(value:unknown):value is CertificationDomain{return value==='ai'||value==='cybersecurity'}
export function filterCertifications(items:Certification[],query:string,category:string,level:string){
 const search=query.trim().toLocaleLowerCase();
 return items.filter(item=>(!category||item.category_id===category)&&(!level||item.level===level)&&(!search||item.title.toLocaleLowerCase().includes(search)));
}
