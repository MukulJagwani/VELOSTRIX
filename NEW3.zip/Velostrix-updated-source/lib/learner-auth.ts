import {headers} from 'next/headers';
import {redirect} from 'next/navigation';
import {waitUntil} from 'cloudflare:workers';
import {config,connections,db,HttpError,json} from './server';
import {dummyPasswordHash,hashPassword,validPassword,verifyPassword} from './passwords';

export type Learner={id:string;name:string;email:string;status:string;email_verified_at:string|null;created_at:string;last_login_at:string|null};
type LearnerRecord=Learner&{password_hash:string;verification_required:number};
const safeFields='id,name,email,status,email_verified_at,created_at,last_login_at';
const sessionLifetime=7*24*60*60*1000;
const idleLifetime=24*60*60*1000;
export const consentVersion='2026-10-05';
function opaqueToken(){return Array.from(crypto.getRandomValues(new Uint8Array(32)),byte=>byte.toString(16).padStart(2,'0')).join('')}
export async function tokenDigest(value:string){const bytes=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value));return Array.from(new Uint8Array(bytes),byte=>byte.toString(16).padStart(2,'0')).join('')}
function siteOrigin(){try{const url=new URL(config('SITE_URL'));if(url.protocol!=='https:'&&!(url.protocol==='http:'&&['127.0.0.1','localhost'].includes(url.hostname)))throw new Error();return url}catch{throw new HttpError(503,'Account services need a valid HTTPS website address.')}}
function cookieName(){return siteOrigin().protocol==='https:'?'__Host-vx_learner':'vx_learner'}
function cookieToken(requestHeaders:Pick<Headers,'get'>){const entry=(requestHeaders.get('cookie')||'').split(';').map(value=>value.trim()).find(value=>value.startsWith(cookieName()+'='));const value=entry?.slice(cookieName().length+1)||'';return /^[a-f0-9]{64}$/.test(value)?value:null}
function cookie(value:string,maxAge:number){return `${cookieName()}=${value}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAge}${siteOrigin().protocol==='https:'?'; Secure':''}`}
export function safeReturnTo(value:unknown){if(typeof value!=='string'||!value.startsWith('/')||value.startsWith('//')||value.includes('\\'))return '/learner';try{const url=new URL(value,'https://velostrix.local');if(url.origin!=='https://velostrix.local'||!/^\/(learner|certifications|courses)(\/|$)/.test(url.pathname))return '/learner';return url.pathname+url.search+url.hash}catch{return '/learner'}}
export async function authRateLimit(req:Request,purpose:string,email='',ipLimit=20,accountLimit=8,windowMs=15*60*1000){
 const now=Date.now(),window=Math.floor(now/windowMs),ip=req.headers.get('cf-connecting-ip')||'local';
 for(const [identity,limit] of [[`ip:${ip}`,ipLimit],...(email?[[`email:${email}`,accountLimit] as const]:[])] as const){
  const key=await tokenDigest(`auth:${purpose}:${window}:${identity}`);
  const result=await db().prepare('INSERT INTO submission_limits (key,count,expires_at) VALUES (?,1,?) ON CONFLICT(key) DO UPDATE SET count=count+1 RETURNING count').bind(key,(window+2)*windowMs).first<{count:number}>();
  if((result?.count||0)>limit)throw new HttpError(429,'Too many attempts. Please wait before trying again.');
 }
 await db().prepare('DELETE FROM submission_limits WHERE expires_at < ?').bind(now).run();
}
export async function readLearner(requestHeaders:Pick<Headers,'get'>):Promise<Learner|null>{
 const token=cookieToken(requestHeaders);if(!token)return null;
 const hash=await tokenDigest(token),now=Date.now();
 const row=await db().prepare(`SELECT ${safeFields.split(',').map(field=>'l.'+field).join(',')} FROM learner_sessions s JOIN learners l ON l.id=s.learner_id WHERE s.token_hash=? AND s.expires_at>? AND s.last_seen_at>? AND l.status='active' AND (l.verification_required=0 OR l.email_verified_at IS NOT NULL)`).bind(hash,now,now-idleLifetime).first<Learner>();
 if(!row)return null;
 await db().prepare('UPDATE learner_sessions SET last_seen_at=? WHERE token_hash=? AND last_seen_at<?').bind(now,hash,now-5*60*1000).run();
 return row;
}
export async function requireLearner(returnTo='/learner'){let learner:Learner|null;try{learner=await readLearner(await headers())}catch{throw new Error('Learner services are temporarily unavailable. Please try again.')}if(!learner)redirect('/learner/login?returnTo='+encodeURIComponent(safeReturnTo(returnTo)));return learner}
export async function apiLearner(req:Request){const learner=await readLearner(req.headers);if(!learner)throw new HttpError(401,'Please log in to your learner account.');return learner}
async function startSession(req:Request,learnerId:string,verifiedHash:string){
 const token=opaqueToken(),now=Date.now(),existing=cookieToken(req.headers);
 const tokenHash=await tokenDigest(token);
 const statements=[db().prepare("INSERT INTO learner_sessions (token_hash,learner_id,created_at,expires_at,last_seen_at) SELECT ?,id,?,?,? FROM learners WHERE id=? AND password_hash=? AND status='active' AND (verification_required=0 OR email_verified_at IS NOT NULL) RETURNING token_hash").bind(tokenHash,now,now+sessionLifetime,now,learnerId,verifiedHash),db().prepare('UPDATE learners SET last_login_at=? WHERE id=? AND EXISTS (SELECT 1 FROM learner_sessions WHERE token_hash=?)').bind(new Date(now).toISOString(),learnerId,tokenHash),db().prepare('DELETE FROM learner_sessions WHERE expires_at<?').bind(now)];
 if(existing)statements.push(db().prepare('DELETE FROM learner_sessions WHERE token_hash=?').bind(await tokenDigest(existing)));
 const results=await db().batch(statements);if(!results[0].results.length)throw new HttpError(401,'Your account changed during login. Please log in again.');return cookie(token,sessionLifetime/1000);
}
function cleanEmail(value:unknown){const email=typeof value==='string'?value.trim().toLowerCase():'';if(email.length>254||!/^\S+@\S+\.\S+$/.test(email))throw new HttpError(400,'Enter a valid email address.');return email}
function passwordInput(input:Record<string,unknown>){if(!validPassword(input.password))throw new HttpError(400,'Use a password or passphrase with 15–128 characters.');if(input.password!==input.confirmPassword)throw new HttpError(400,'Passwords do not match.');return input.password}
async function sendAccountEmail(learner:{id:string;email:string},purpose:'verify'|'reset'){
 if(!connections().email)throw new HttpError(503,'Account emails are not connected yet. Please contact Velostrix for help.');
 const origin=siteOrigin();
 const token=opaqueToken(),hash=await tokenDigest(token),now=Date.now();
 await db().batch([db().prepare('DELETE FROM learner_tokens WHERE learner_id=? AND purpose=?').bind(learner.id,purpose),db().prepare('INSERT INTO learner_tokens (token_hash,learner_id,purpose,expires_at,created_at) VALUES (?,?,?,?,?)').bind(hash,learner.id,purpose,now+(purpose==='reset'?30*60*1000:24*60*60*1000),now)]);
 const url=new URL('/learner/'+(purpose==='reset'?'reset-password':'verify-email'),origin.origin);url.searchParams.set('token',token);
 try{const response=await fetch('https://api.resend.com/emails',{method:'POST',headers:{Authorization:'Bearer '+config('RESEND_API_KEY'),'Content-Type':'application/json'},body:JSON.stringify({from:config('EMAIL_FROM'),to:[learner.email],subject:purpose==='reset'?'Reset your Velostrix password':'Verify your Velostrix email',text:`${purpose==='reset'?'Reset your password':'Verify your email address'} using this single-use link:\n\n${url}\n\nIf you did not request this, you can ignore this message.`}),signal:AbortSignal.timeout(12000)});if(!response.ok)throw new Error();}catch{await db().prepare('DELETE FROM learner_tokens WHERE token_hash=?').bind(hash).run();throw new HttpError(503,'The email could not be sent. Please try again later.');}
}
export async function learnerAuthAction(req:Request,action:string,input:Record<string,unknown>){
 if(action==='logout'){
  const token=cookieToken(req.headers);if(token)await db().prepare('DELETE FROM learner_sessions WHERE token_hash=?').bind(await tokenDigest(token)).run();
  const response=json({ok:true});response.headers.set('Set-Cookie',cookie('',0));return response;
 }
 if(action==='signup'){
  const email=cleanEmail(input.email);await authRateLimit(req,'signup',email,6,3,60*60*1000);
  const name=typeof input.name==='string'?input.name.trim():'';if(name.length<2||name.length>100)throw new HttpError(400,'Enter your full name (2–100 characters).');
  const password=passwordInput(input);if(input.acceptTerms!==true)throw new HttpError(400,'Please accept the learner terms and privacy notice.');
  const hash=await hashPassword(password),id=crypto.randomUUID(),now=new Date().toISOString(),verificationRequired=connections().email?1:0;
  const inserted=await db().prepare("INSERT INTO learners (id,name,email,password_hash,status,verification_required,consent_at,consent_version,created_at) VALUES (?,?,?,?,'active',?,?,?,?) ON CONFLICT(email) DO NOTHING RETURNING id").bind(id,name,email,hash,verificationRequired,now,consentVersion,now).first();
  if(!inserted)throw new HttpError(409,'An account cannot be created with these details. Try logging in or resetting your password.');
  if(verificationRequired){await sendAccountEmail({id,email},'verify');return json({ok:true,verifyEmail:true,message:'Check your email to verify your account before logging in.'},201)}
  const response=json({ok:true,emailVerified:false,redirect:safeReturnTo(input.returnTo)},201);response.headers.set('Set-Cookie',await startSession(req,id,hash));return response;
 }
 if(action==='login'){
  const email=cleanEmail(input.email);await authRateLimit(req,'login',email);
  const password=typeof input.password==='string'&&input.password.length<=128?input.password:'';
  const learner=await db().prepare('SELECT * FROM learners WHERE email=?').bind(email).first<LearnerRecord>();
  const valid=await verifyPassword(password,learner?.password_hash||dummyPasswordHash);
  if(!learner||!valid||learner.status!=='active')throw new HttpError(401,'Email or password is incorrect, or the account is unavailable.');
  if(learner.verification_required&&!learner.email_verified_at)throw new HttpError(403,'Verify your email before logging in. You can request a new verification email below.');
  const response=json({ok:true,redirect:safeReturnTo(input.returnTo)});response.headers.set('Set-Cookie',await startSession(req,learner.id,learner.password_hash));return response;
 }
 if(action==='forgot-password'||action==='resend-verification'){
  const email=cleanEmail(input.email);await authRateLimit(req,action,email,10,3,60*60*1000);
  if(!connections().email)throw new HttpError(503,'Email recovery and verification are not connected yet. Please contact Velostrix for help.');
  const learner=await db().prepare("SELECT id,email,email_verified_at FROM learners WHERE email=? AND status='active'").bind(email).first<{id:string;email:string;email_verified_at:string|null}>();
  if(learner&&(action==='forgot-password'||!learner.email_verified_at))waitUntil(sendAccountEmail(learner,action==='forgot-password'?'reset':'verify').catch(()=>{console.error('Learner recovery email delivery failed.');}));
  return json({ok:true,message:'If an eligible account matches this email, instructions will be sent. Please check your inbox and spam folder. If nothing arrives, try again later or contact Velostrix.'});
 }
 if(action==='reset-password'||action==='verify-email'){
  await authRateLimit(req,action,'',12);
  const token=typeof input.token==='string'?input.token:'';if(!/^[a-f0-9]{64}$/.test(token))throw new HttpError(400,'This link is invalid or expired. Please request a new one.');
  const hash=await tokenDigest(token),now=Date.now(),purpose=action==='reset-password'?'reset':'verify';
  const found=await db().prepare("SELECT t.learner_id FROM learner_tokens t JOIN learners l ON l.id=t.learner_id WHERE t.token_hash=? AND t.purpose=? AND t.expires_at>? AND l.status='active'").bind(hash,purpose,now).first<{learner_id:string}>();
  if(!found)throw new HttpError(400,'This link is invalid or expired. Please request a new one.');
  const statements=[];
  if(purpose==='reset'){
   const passwordHash=await hashPassword(passwordInput(input)),resetTime=Date.now();
   statements.push(db().prepare("UPDATE learners SET password_hash=? WHERE id=? AND EXISTS (SELECT 1 FROM learner_tokens WHERE token_hash=? AND purpose='reset' AND expires_at>?) RETURNING id").bind(passwordHash,found.learner_id,hash,resetTime));
   statements.push(db().prepare('DELETE FROM learner_sessions WHERE learner_id=? AND EXISTS (SELECT 1 FROM learner_tokens WHERE token_hash=? AND expires_at>?)').bind(found.learner_id,hash,resetTime));
  }else statements.push(db().prepare("UPDATE learners SET email_verified_at=? WHERE id=? AND EXISTS (SELECT 1 FROM learner_tokens WHERE token_hash=? AND purpose='verify' AND expires_at>?) RETURNING id").bind(new Date(now).toISOString(),found.learner_id,hash,now));
  statements.push(db().prepare('DELETE FROM learner_tokens WHERE learner_id=? AND purpose=? AND EXISTS (SELECT 1 FROM learner_tokens WHERE token_hash=?)').bind(found.learner_id,purpose,hash));
  const results=await db().batch(statements);if(!results[0].results.length)throw new HttpError(400,'This link has already been used. Please request a new one.');
  const response=json({ok:true,message:purpose==='reset'?'Your password has been changed. Please log in again.':'Your email is verified. You can now log in.'});if(purpose==='reset')response.headers.set('Set-Cookie',cookie('',0));return response;
 }
 throw new HttpError(404,'Account action not found.');
}
