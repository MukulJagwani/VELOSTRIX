import { existsSync,mkdirSync,readFileSync,writeFileSync } from "node:fs";
import { spawnSync } from "node:child_process";
import path from "node:path";
const root=process.cwd();
const full=process.argv.includes("--setup");
function run(args){const result=spawnSync(process.execPath,args,{stdio:"inherit",cwd:root});if(result.status!==0)process.exit(result.status||1);}
if(full){
 const values="ADMIN_EMAILS=seedy@sites.test\nCONTACT_EMAIL=velostrixsecurity@gmail.com\nSITE_URL=http://127.0.0.1:5173\nRAZORPAY_KEY_ID=\nRAZORPAY_KEY_SECRET=\nRAZORPAY_WEBHOOK_SECRET=\nRESEND_API_KEY=\nEMAIL_FROM=\n";
 if(!existsSync(".dev.vars"))writeFileSync(".dev.vars",values);
 if(!existsSync(".env"))writeFileSync(".env",values);
 run(["scripts/run-framework.mjs","build"]);
}
if(!existsSync("dist/server/wrangler.json"))throw new Error("Run npm run build first.");
const built=JSON.parse(readFileSync("dist/server/wrangler.json","utf8"));
mkdirSync(".sites-runtime",{recursive:true});
const migrationConfig={name:built.name,compatibility_date:built.compatibility_date,d1_databases:built.d1_databases.map(d=>({...d,migrations_dir:path.join(root,"drizzle")}))};
const config=path.join(root,".sites-runtime","local-migrations.json");
writeFileSync(config,JSON.stringify(migrationConfig,null,2));
run(["--import","./scripts/sites-env.mjs","./node_modules/wrangler/bin/wrangler.js","d1","migrations","apply","DB","--local","--config",config,"--persist-to",".wrangler/state"]);
