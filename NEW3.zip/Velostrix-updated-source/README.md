# Velostrix website

A responsive Cyber & AI Security bootcamp website with a protected admissions dashboard, persistent applications, CSV export, PDF policy storage and optional Razorpay / Resend integrations.

## Included features

- CompTIA-inspired page composition, blue-and-white branding, sticky navigation, search and quick links.
- Home, Courses, Bootcamp, Curriculum, Careers, About, Resources and Contact pages, plus three original learning guides.
- Six course destinations, a responsive Courses menu, course-specific enquiries and a highlighted Cybersecurity Master Course with 75% practical training / 25% theory.
- Contact icons and a floating WhatsApp link using the business number in `lib/content.ts`.
- Interactive curriculum, pricing, FAQs and a five-field application: name, location, contact number, email and course.
- Counselling callback and fee quote requests, saved separately from applications.
- Server-side validation, duplicate-email protection and submission limits.
- Admin-only application review, search, filtering and status updates.
- CSV export with spreadsheet formula protection.
- Policy PDF uploads up to 5 MB, stable public links and replacement.
- Razorpay payment links for approved applicants and signature-verified payment events.
- Optional email notifications for new applications.
- Explicit connection status; no simulated payment or email success.
- Browser agent tool for filtering the admin view.

## Local setup

Requires Node.js 22.13 or later and npm.

```sh
npm ci
npm run setup:local
npm run dev
```

Open the exact URL printed by the development server, usually http://127.0.0.1:5173.

`setup:local` creates a local-only development environment if none exists, builds the Worker, and applies migrations using Wrangler's local migration tracking. Existing environment files are preserved. The first run may take a few minutes.

Local admin sign-in is simulated by the development runtime. Open `/admin` to use the local account `seedy@sites.test`. This simulation is excluded from production.

## Admin workflow

1. Open `/admin` and sign in with an authorised account.
2. Use **Applications** to review submissions, search and export CSV.
3. Open **Review** to change an application from New to Contacted, Approved or Rejected.
4. When Razorpay is connected, approved applicants can have a payment link created. Copy the link and share it with that applicant.
5. Verified payment events update the payment status. Once a link has been requested, the application status is locked to avoid conflicting enrollment and payment decisions.
6. Use **Policy PDFs** to upload Privacy, Terms and Refund PDFs. Public footer links become active automatically. Until then, they open an email request.
7. Use **Connections** to see whether email and payments are configured.
8. Use **Enquiries** for callback and quote requests. Contact the learner to agree a time, record the confirmed time in IST, and add internal notes. This workflow does not automatically send a calendar invitation or confirmation to the learner.

## Production configuration

The project targets Cloudflare Workers with a D1 database bound as `DB` and an R2 bucket bound as `BUCKET`. Hosted authentication uses the Sites platform's trusted, server-injected identity headers and sign-in routes. The owner email allowlist is checked on every admin request.

The protected admin routes MUST NOT be exposed behind an arbitrary proxy that accepts visitor-supplied `oai-authenticated-user-*` headers. If moving away from Sites, replace this identity integration with a verified authentication provider and keep server-side authorization.

Use your hosting provider's secret settings for these values. Never put them in browser code or commit private environment files:

| Variable | Purpose |
| --- | --- |
| ADMIN_EMAILS | Comma-separated authorised admin account emails |
| CONTACT_EMAIL | Address that receives application notifications |
| SITE_URL | Canonical HTTPS website origin |
| RAZORPAY_KEY_ID | Razorpay API key ID |
| RAZORPAY_KEY_SECRET | Razorpay API secret |
| RAZORPAY_WEBHOOK_SECRET | Secret used to verify incoming Razorpay events |
| RESEND_API_KEY | Resend email API key |
| EMAIL_FROM | Verified sender, for example Velostrix <admissions@yourdomain.in> |

In Razorpay, register `https://YOUR_DOMAIN/api/webhooks/razorpay` and subscribe to `payment_link.paid`. Use separate test credentials first. Payments are not enabled until the required keys and webhook secret are present. The server owns the program price of INR 49,999 (4,999,900 paise); it never trusts a browser-provided amount.

The payment-link flow uses a unique application reference, serialises creation and reconciles uncertain responses rather than issuing duplicate links. Webhooks verify the unmodified body, amount, currency and paid status, and deduplicate event IDs. A link in **Needs review** is reconciled using **Refresh payment link**. If the provider rejected creation and no link exists, resolve it with the gateway before clearing that application's pending attempt.

Application records are saved even without email delivery. Notification failures appear in the admin panel and can be retried after email is connected. Resend requires a verified sender domain.

Official integration references:
- https://razorpay.com/docs/api/payments/payment-links/create-standard/
- https://razorpay.com/docs/api/payments/payment-links/fetch-all-standard/
- https://razorpay.com/docs/webhooks/validate-test/
- https://resend.com/docs/api-reference/emails/send-email

## Data and migrations

Schema: `db/schema.ts`. Generated SQL and snapshots: `drizzle/`.

```sh
npm run db:generate
npm run db:local
npm run build
```

Generate a new migration when the schema changes. Preserve migrations already applied to a deployed database. Runtime route handlers do not create or alter tables.

Local databases and files are kept in ignored `.wrangler/state/`. They are not included in the source archive or deployment. Do not delete that directory if you need to retain local data.

## Editing content

- `app/page.tsx`: homepage composition.
- `components/site-chrome.tsx`: navigation, search, quick links, sidebar and footer.
- `app/sections.tsx`: curriculum tabs, FAQs and application/enquiry form.
- `app/marketing.css`: redesigned public website styling.
- `app/globals.css`: shared tokens and admin styling.
- `lib/content.ts`: company details, curriculum, career support and resource articles.
- `lib/courses.ts`: course names, descriptions, learning areas and enquiry destinations; shared by navigation, search, forms and server validation.
- `components/course-catalogue.tsx`: course cards and the flagship programme panel.
- `components/contact-details.tsx`: contact links and the floating WhatsApp button.
- `components/learning-journey.tsx`: Learn → Practice → Secure → Certify → Advance visual.
- `app/course-updates.css`: responsive course, contact, logo and journey styles extending the existing design.
- `app/admin/dashboard.tsx`: admin interface.
- `app/admin/enquiries.tsx`: callback and quote follow-up.
- `lib/domain.ts`: application segments, statuses and authoritative payment amount.
- `lib/server.ts`: authentication, storage and integration logic.
- `app/api/[...path]/route.ts`: API routes.

Change both the visible pricing copy and the server-owned amount together when changing the tuition fee.

The six new courses have no configured fees, durations, batch dates or external certification claims. Their enquiry selections are stored in the existing backend. Payment creation remains available only for the original Cyber & AI Security Bootcamp; new courses must receive explicit pricing and corresponding server-side payment support before payment links can be issued. Cloud Security covers vendor-neutral security concepts. AI course categories are available as a structure for future confirmed programmes.

The storytelling illustration is an original AI-generated asset, optimised as `public/security-learning-journey.webp`. Social icon attribution is in `public/icons/NOTICE.txt`. Set `company.phone` in `lib/content.ts` to an international-format number beginning with `+`; the same value powers phone and WhatsApp links.

## Release notes

The redesign adds an additive database migration: applications gain location and course fields, and enquiries have their own table. Preserve the previously deployed migration and existing data. The homepage portrait is an illustrative AI-generated learner, not a customer testimonial or staff photograph. The program retains 20 seats, a 12-week duration and a ₹49,999 fee. Q4 2026 is the planned launch window, not a confirmed start date.

Earlier integration checks covered the original application, admin, export and PDF workflows. The redesigned release is compiled and visually reviewed; a live payment/email test and an end-to-end admissions test should be performed with your configured production services before public launch.

Real payment collection and email delivery require the owner's connected service accounts and a final test with those accounts. Policy PDFs and currently undecided cohort dates/schedules must be supplied by Velostrix.


## AI, certifications and learner accounts

This update extends the current Vinext/Cloudflare website. It preserves the original bootcamp, admissions, Razorpay, policy PDF and contact workflows.

- `/courses` separates AI learning categories from the seven cybersecurity courses. AI categories are not advertised as confirmed courses. Cyber Law is free; other new course prices remain unconfigured.
- `/certifications` provides AI and cybersecurity paths. `/certifications/ai` contains 73 titles from the supplied AI CERTs catalogue, with original short descriptions. Inclusion was confirmed by the website owner. Three cybersecurity entries are informational certification pathways. No partnership, accreditation, voucher or examination inclusion is claimed.
- `lib/certification-seed.ts` holds the initial catalogue. D1 records override matching IDs. Admins can add records, change categories/order, or hide entries by setting them to draft. Publishing requires confirmation of promotion rights and accurate information. Preserve existing IDs to keep saved interests and URLs working.
- `/login` separates learner accounts from the existing ChatGPT-based admin sign-in. Local admin simulation is restricted to loopback development; hosted admin access requires the trusted Sites identity gateway and an email listed in `ADMIN_EMAILS`. Do not expose the raw Worker outside that gateway.
- Learners use standard email addresses. Passwords use salted scrypt (N=32768, r=8, p=3); admins never receive password hashes. Session and recovery tokens are stored as SHA-256 digests. Cookies are HttpOnly, SameSite=Lax and Secure on HTTPS; sessions expire after seven days or 24 hours idle. Login rotates sessions; reset, logout and suspension revoke them.
- Signup records acceptance of the learner account notice. Server-side validation, origin checks and database-backed rate limits protect account and learner mutations. The admin cannot promote learner accounts to admin roles.
- When `RESEND_API_KEY` and a verified `EMAIL_FROM` are configured, new accounts must verify their email before login. Verification links expire in 24 hours; reset links expire in 30 minutes. Both are single use. Set `SITE_URL` to the exact HTTPS public origin before enabling emails. Without a connected sender, signup remains available and accurately labels email as unverified; recovery and verification email buttons explain that delivery is unavailable.
- Free Cyber Law enrolment leads to six introductory lessons, saved progress and a six-question knowledge check. Five correct answers issue one private Velostrix Certificate of Completion, printable as PDF by its learner. This is general educational content, not jurisdiction-specific legal advice or an accredited professional qualification.
- `/admin` → **Learners & certifications** shows safe account information, enrolments and certification interests, supports suspension/reactivation, and manages catalogue records. Course content continues to be maintained in `lib/courses.ts`.
- `app/learning-updates.css` extends the existing design and respects reduced motion. `components/site-link.tsx` uses normal anchor navigation to avoid the installed Vinext production build's RSC-prefetch callback error; URLs, keyboard behavior and modifier-clicks are preserved.

### Database upgrade and verification

The additive `0002_pretty_centennial.sql` migration introduces learner accounts, sessions, one-time tokens, enrolments, lesson progress, assessments, completion records and certification overrides/interests. Apply it using the existing migration workflow; never delete an existing database to upgrade it.

```sh
npm run build
npm run db:local
npm run dev
```

For a fresh extracted source copy use `npm ci`, then `npm run setup:local`, then `npm run dev`. Open the printed localhost URL; this application requires its backend and does not use VS Code Live Server.

Checks available:

```sh
npm run lint
npm run test
npx tsc --noEmit
npm run build
```

The tests use an isolated in-memory SQLite database and test doubles for the Sites identity/email boundary. They never create real learners or send email/payments. Production email delivery and payment collection still require the owner's configured accounts.

### Privacy operations

Learner data is limited to account identity, consent, learning progress and saved interests. The account notice provides the verified business email for correction or deletion requests. Authorised operators should process those requests through controlled database operations; deleting a learner cascades to learner-owned records. Keep database backups and operational logs private, and establish a business retention policy before broad public use. No learner PII belongs in frontend seed data or public analytics.
