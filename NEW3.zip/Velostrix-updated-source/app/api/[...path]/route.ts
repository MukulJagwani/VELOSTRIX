import { admin,body,bucket,connections,createPayment,db,HttpError,json,notifyApplication,notifyEnquiry,paymentWebhook,rateLimit,sameOrigin,validateApplication } from "@/lib/server";
import { policyLabels,statuses,enquiryStatuses,type Application,type Enquiry } from "@/lib/domain";
import {learningApi} from '@/lib/learning-api';
export const dynamic="force-dynamic";
async function route(req:Request){
 try {
 const path=new URL(req.url).pathname.replace(/^\/api\//,"");
 if(path==="webhooks/razorpay"&&req.method==="POST")return await paymentWebhook(req);
 if(req.method!=="GET")sameOrigin(req);
 const learning=await learningApi(req,path);if(learning)return learning;
 if(path==="applications"&&req.method==="POST"){
   const input=validateApplication(await body(req));await rateLimit(req);
   const id=crypto.randomUUID(),now=new Date().toISOString();
   const inserted=await db().prepare("INSERT INTO applications (id,name,email,phone,segment,location,course,status,payment_status,notification_status,created_at,updated_at) VALUES (?,?,?,?,?,?,?,'New','Unpaid','Not configured',?,?) ON CONFLICT(email) DO NOTHING RETURNING id").bind(id,input.name,input.email,input.phone,input.segment,input.location,input.course,now,now).first();
   if(inserted){const a=await db().prepare("SELECT * FROM applications WHERE id=?").bind(id).first<Application>();const status=await notifyApplication(a!);await db().prepare("UPDATE applications SET notification_status=? WHERE id=?").bind(status,id).run();}
   return json({ok:true,message:"Thank you. Your application has been received. The Velostrix team will contact you about the next steps."},201);
 }
 if(path==="enquiries"&&req.method==="POST"){
   const x=await body(req),input=validateApplication(x);await rateLimit(req);
   if(!['callback','quote'].includes(x.request_type))throw new HttpError(400,"Choose a valid request type.");
   if(typeof x.request_id!=='string'||! /^[a-f0-9-]{36}$/.test(x.request_id))throw new HttpError(400,"Please refresh the form and try again.");
   const preferred=typeof x.preferred_time==='string'?x.preferred_time.trim():'',message=typeof x.message==='string'?x.message.trim():'';
   if(preferred.length>150||message.length>2000)throw new HttpError(400,"Please shorten your message or preferred time.");
   const now=new Date().toISOString();
   const inserted=await db().prepare("INSERT INTO enquiries (id,name,email,phone,location,course,request_type,preferred_time,message,status,notification_status,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,'New','Not configured',?,?) ON CONFLICT(id) DO NOTHING RETURNING id").bind(x.request_id,input.name,input.email,input.phone,input.location,input.course,x.request_type,preferred,message,now,now).first();
   if(inserted){const a=await db().prepare("SELECT * FROM enquiries WHERE id=?").bind(x.request_id).first<Enquiry>();const status=await notifyEnquiry(a!);await db().prepare("UPDATE enquiries SET notification_status=? WHERE id=?").bind(status,x.request_id).run();}
   return json({ok:true},201);
 }
 if(path==="policies"&&req.method==="GET"){
   const result=await db().prepare("SELECT slug,label,file_name,updated_at FROM policies ORDER BY slug").all();return json({policies:result.results});
 }
 if(path.startsWith("policies/")&&req.method==="GET"){
   const slug=path.split("/")[1];if(!policyLabels[slug])throw new HttpError(404,"Policy not found.");
   const p=await db().prepare("SELECT object_key FROM policies WHERE slug=?").bind(slug).first<{object_key:string}>();
   if(!p)throw new HttpError(404,"This PDF is not yet available. Please contact Velostrix.");
   const file=await bucket().get(p.object_key);if(!file)throw new HttpError(404,"Document not found.");
   return new Response(file.body,{headers:{"Content-Type":"application/pdf","Content-Disposition":'inline; filename="velostrix-'+slug+'-policy.pdf"',"Cache-Control":"no-store","X-Content-Type-Options":"nosniff"}});
 }
 if(!path.startsWith("admin/"))throw new HttpError(404,"Not found.");
 await admin();
 if(path==="admin/data"&&req.method==="GET"){
   const [apps,policies,enquiries]=await Promise.all([db().prepare("SELECT * FROM applications ORDER BY created_at DESC").all(),db().prepare("SELECT slug,label,file_name,updated_at FROM policies").all(),db().prepare("SELECT * FROM enquiries ORDER BY created_at DESC").all()]);
   return json({applications:apps.results,enquiries:enquiries.results,policies:policies.results,connections:connections()});
 }
 if((path==="admin/export"||path==="admin/enquiries/export")&&req.method==="GET"){
   const isEnquiry=path==="admin/enquiries/export";
   const rows=await db().prepare(isEnquiry?"SELECT * FROM enquiries ORDER BY created_at DESC":"SELECT name,email,phone,location,course,segment,status,payment_status,created_at FROM applications ORDER BY created_at DESC").all();
   const safe=(x:unknown)=>{let s=String(x??"");if(/^[=+@\-\t\r]/.test(s))s="'"+s;return '"'+s.replace(/"/g,'""')+'"';};
   const cols=isEnquiry?["name","email","phone","location","course","request_type","preferred_time","message","status","scheduled_at","admin_note","created_at"]:["name","email","phone","location","course","segment","status","payment_status","created_at"];
   const csv="\uFEFF"+[cols.map(safe).join(","),...rows.results.map(r=>cols.map(k=>safe(r[k])).join(","))].join("\r\n");
   return new Response(csv,{headers:{"Content-Type":"text/csv; charset=utf-8","Content-Disposition":'attachment; filename="velostrix-'+(isEnquiry?'enquiries':'applications')+'.csv"',"Cache-Control":"no-store","X-Content-Type-Options":"nosniff"}});
 }
 const enquiry=path.match(/^admin\/enquiries\/([a-f0-9-]{36})$/);
 if(enquiry&&req.method==="PATCH"){
   const x=await body(req);if(!(enquiryStatuses as readonly string[]).includes(x.status))throw new HttpError(400,"Choose a valid enquiry status.");
   const note=typeof x.admin_note==='string'?x.admin_note.trim():'';if(note.length>2000)throw new HttpError(400,"Use a note under 2,000 characters.");
   const existing=await db().prepare("SELECT request_type FROM enquiries WHERE id=?").bind(enquiry[1]).first<{request_type:string}>();if(!existing)throw new HttpError(404,"Enquiry not found.");
   const scheduled=typeof x.scheduled_at==='string'&&x.scheduled_at?x.scheduled_at:null;
   if(scheduled&&(!/^\d{4}-\d{2}-\d{2}T/.test(scheduled)||!Number.isFinite(Date.parse(scheduled))))throw new HttpError(400,"Enter a valid call date and time.");
   if(x.status==='Call scheduled'&&(existing.request_type!=='callback'||!scheduled))throw new HttpError(400,"Only callback requests with a confirmed date can be scheduled.");
   await db().prepare("UPDATE enquiries SET status=?,admin_note=?,scheduled_at=?,updated_at=? WHERE id=?").bind(x.status,note,scheduled?new Date(scheduled).toISOString():null,new Date().toISOString(),enquiry[1]).run();return json({ok:true});
 }
 const enquiryNotification=path.match(/^admin\/enquiry-notifications\/([a-f0-9-]{36})$/);
 if(enquiryNotification&&req.method==="POST"){
   const a=await db().prepare("SELECT * FROM enquiries WHERE id=?").bind(enquiryNotification[1]).first<Enquiry>();if(!a)throw new HttpError(404,"Enquiry not found.");
   if(!connections().email)throw new HttpError(503,"Connect email delivery first.");if(a.notification_status==='Sent')return json({ok:true});const status=await notifyEnquiry(a);await db().prepare("UPDATE enquiries SET notification_status=? WHERE id=?").bind(status,a.id).run();if(status!=='Sent')throw new HttpError(502,"The notification could not be delivered.");return json({ok:true});
 }
 const application=path.match(/^admin\/applications\/([a-f0-9-]{36})$/);
 if(application&&req.method==="PATCH"){
   const input=await body(req);
   if(!(statuses as readonly string[]).includes(input.status))throw new HttpError(400,"Choose a valid application status.");
   const result=await db().prepare("UPDATE applications SET status=?,updated_at=? WHERE id=? AND payment_status!='Paid' AND (payment_attempt IS NULL OR ?='Approved') RETURNING id").bind(input.status,new Date().toISOString(),application[1],input.status).first();
   if(!result)throw new HttpError(409,"This application cannot be changed after a payment link is created or payment is confirmed.");
   return json({ok:true});
 }
 const payment=path.match(/^admin\/payments\/([a-f0-9-]{36})$/);
 if(payment&&req.method==="POST")return json(await createPayment(payment[1]));
 const notification=path.match(/^admin\/notifications\/([a-f0-9-]{36})$/);
 if(notification&&req.method==="POST"){
   const a=await db().prepare("SELECT * FROM applications WHERE id=?").bind(notification[1]).first<Application>();
   if(!a)throw new HttpError(404,"Application not found.");
   if(!connections().email)throw new HttpError(503,"Connect email delivery first.");
   if(a.notification_status==="Sent")return json({ok:true});
   const status=await notifyApplication(a);await db().prepare("UPDATE applications SET notification_status=? WHERE id=?").bind(status,a.id).run();
   if(status!=="Sent")throw new HttpError(502,"The notification could not be delivered.");return json({ok:true});
 }
 const policy=path.match(/^admin\/policies\/(privacy|terms|refund)$/);
 if(policy&&req.method==="PUT"){
   if(Number(req.headers.get("content-length")||0)>5*1024*1024)throw new HttpError(413,"Use a PDF smaller than 5 MB.");
   const bytes=await req.arrayBuffer();if(bytes.byteLength>5*1024*1024)throw new HttpError(413,"Use a PDF smaller than 5 MB.");
   if(new TextDecoder().decode(bytes.slice(0,5))!=="%PDF-")throw new HttpError(400,"Please upload a valid PDF file.");
   const slug=policy[1],objectKey="policies/"+slug+"/"+crypto.randomUUID()+".pdf",now=new Date().toISOString();
   const old=await db().prepare("SELECT object_key FROM policies WHERE slug=?").bind(slug).first<{object_key:string}>();
   await bucket().put(objectKey,bytes,{httpMetadata:{contentType:"application/pdf"}});
   const filename="velostrix-"+slug+"-policy.pdf";
   try{await db().prepare("INSERT INTO policies (slug,label,object_key,file_name,updated_at) VALUES (?,?,?,?,?) ON CONFLICT(slug) DO UPDATE SET object_key=excluded.object_key,file_name=excluded.file_name,updated_at=excluded.updated_at").bind(slug,policyLabels[slug],objectKey,filename,now).run();}catch(e){await bucket().delete(objectKey);throw e;}
   if(old)try{await bucket().delete(old.object_key)}catch{console.error("Previous policy cleanup pending");}
   return json({ok:true});
 }
 throw new HttpError(404,"Not found.");
 }catch(e){if(e instanceof HttpError)return json({error:e.message},e.status);console.error("Velostrix request failed",e instanceof Error?e.message:"Unknown error");return json({error:"We could not complete that request. Please try again; your details have been kept on this page."},503);}
}
export const GET=route;export const POST=route;export const PATCH=route;export const PUT=route;
