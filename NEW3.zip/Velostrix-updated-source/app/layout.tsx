import type { Metadata } from "next";
import "./globals.css";
import "./marketing.css";
import "./course-updates.css";
import "./learning-updates.css";

export const metadata: Metadata = {
  title: { default: "Velostrix — AI & Cybersecurity Training", template: "%s | Velostrix" },
  description: "Build future-ready skills in Artificial Intelligence and Cybersecurity. Explore AI certifications, cybersecurity courses, practical training and free Cyber Law learning with Velostrix.",
  openGraph: {title: "Velostrix — AI & Cybersecurity Training",description: "Practical learning, certification pathways and future skills in Artificial Intelligence and Cybersecurity.",type: "website",siteName: "Velostrix"},
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
