import { SiteShell, PageIntro } from '@/components/site-shell';
import { CourseCatalogue } from '@/components/course-catalogue';

export const metadata = {
  title: 'Artificial Intelligence & Cybersecurity Courses',
  description: 'Explore AI learning areas and cybersecurity courses in networking, ethical hacking, penetration testing and Cloud Security. Enrol in free Cyber Law learning.',
};

export default async function CoursesPage({searchParams}:{searchParams:Promise<{category?:string}>}) {
  const {category}=await searchParams;
  return <SiteShell><div className="vx-container vx-page-content"><PageIntro kicker="VELOSTRIX COURSES" title="Build your future in AI & Cybersecurity." description="Explore Artificial Intelligence and Cybersecurity learning paths. Find your starting point, deepen your practical skills and prepare for the future of technology." /><CourseCatalogue key={category||'cybersecurity'} initialCategory={category} /></div></SiteShell>;
}
