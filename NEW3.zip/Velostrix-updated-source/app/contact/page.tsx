import {SiteShell,PageIntro} from '@/components/site-shell';
import {InquiryForm} from '@/app/sections';
import {EmailLink,PhoneLink,LocationLink,HoursDetail,InstagramLink,WhatsAppLink} from '@/components/contact-details';
import {company} from '@/lib/content';
import {findCourse} from '@/lib/courses';
export const metadata={title:'Contact & Apply',description:'Enquire about Velostrix courses, apply for a programme or request a counselling callback.'};
export default async function Contact({searchParams}:{searchParams:Promise<{intent?:string;course?:string}>}){
 const {intent,course}=await searchParams;
 const selected=intent==='callback'||intent==='quote'?intent:'application';
 const selectedCourse=findCourse(course);
 return <SiteShell><div className="vx-container"><PageIntro kicker="CONNECT WITH VELOSTRIX" title="Let’s talk about your next chapter." description="Explore a course, apply for a programme, request a counselling call or get fee details. Our team is here to help you make an informed decision."/><div className="vx-contact-layout"><div className="vx-contact-info"><div><h2>Email our team</h2><EmailLink/>{company.phone&&<><PhoneLink/><WhatsAppLink/></>}</div><div><h2>When we’re available</h2><HoursDetail/></div><div><h2>Learn from anywhere in India</h2><LocationLink/><p>All training is delivered live online.</p></div><div><h2>Stay connected</h2><InstagramLink/></div><p className="vx-note">{selectedCourse?'Ask our team about the '+selectedCourse.name+' syllabus, fees and availability.': 'The founding bootcamp cohort has 20 seats. The 12-week bootcamp fee is ₹49,999. Dates and schedules will be confirmed before enrollment.'}</p></div><InquiryForm key={selected+':'+(selectedCourse?.id||'bootcamp')} initialIntent={selected} initialCourse={selectedCourse?.name||company.course}/></div></div></SiteShell>
}
