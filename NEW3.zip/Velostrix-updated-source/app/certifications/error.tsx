'use client';
export default function CertificationError({reset}:{reset:()=>void}){return <main className="vx-site vx-container vx-error-boundary"><h1>The catalogue is temporarily unavailable.</h1><p>Please try again or contact Velostrix for certification details.</p><button className="vx-button" onClick={reset}>Try again</button></main>}
