import {notFound} from 'next/navigation';
import {SiteShell,PageIntro} from '@/components/site-shell';
import {CertificationCatalogue} from '@/components/certification-catalogue';
import {certificationCategory,validDomain,type Certification} from '@/lib/certifications';
import {getCertifications} from '@/lib/learning-server';
export const dynamic='force-dynamic';
export async function generateMetadata({params}:{params:Promise<{domain:string}>}){const {domain}=await params;return {title:domain==='ai'?'AI Certifications':'Cybersecurity Certifications',description:'Explore Velostrix certification pathways. Search by name and browse relevant learning categories.'}}
export default async function CataloguePage({params,searchParams}:{params:Promise<{domain:string}>;searchParams:Promise<{category?:string;q?:string;level?:string}>}){
 const {domain}=await params;if(!validDomain(domain))notFound();const search=await searchParams;
 let records:Certification[]=[],unavailable=false;try{records=await getCertifications(domain)}catch{unavailable=true}
 const category=search.category&&certificationCategory(search.category)?.domain===domain?search.category:'';
 return <SiteShell><div className="vx-container vx-page-content"><PageIntro kicker="EXPLORE CERTIFICATIONS" title={domain==='ai'?'Artificial Intelligence certifications.':'Cybersecurity certification pathways.'} description={domain==='ai'?'Discover AI learning across business, security, cloud, development and more. Search the catalogue and find your direction.':'Explore a focused selection of foundational certification pathways for networking and cybersecurity.'}/><CertificationCatalogue domain={domain} records={records} initialCategory={category} initialQuery={(search.q||'').slice(0,100)} initialLevel={records.some(item=>item.level===search.level)?search.level:''} unavailable={unavailable}/></div></SiteShell>
}
