import Link from '@/components/site-link';
import {notFound} from 'next/navigation';
import {SiteShell,PageIntro} from '@/components/site-shell';
import {resources} from '@/lib/content';
export function generateStaticParams(){return resources.map(r=>({slug:r.slug}))}
export async function generateMetadata({params}:{params:Promise<{slug:string}>}){const {slug}=await params;const r=resources.find(x=>x.slug===slug);return {title:r?.title||'Resource not found',description:r?.description}}
export default async function Resource({params}:{params:Promise<{slug:string}>}){const {slug}=await params;const r=resources.find(x=>x.slug===slug);if(!r)notFound();return <SiteShell><div className="vx-container"><PageIntro kicker={r.category} title={r.title} description={r.description}/><article className="vx-article"><span className="vx-kicker">VELOSTRIX FIELD NOTES</span>{r.sections.map(([heading,text])=><section key={heading}><h2>{heading}</h2><p>{text}</p></section>)}<div className="vx-note">Explore how these ideas fit into our live, 12-week Cyber & AI Security Bootcamp.</div><div className="vx-button-row"><Link className="vx-button" href="/bootcamp">Explore the bootcamp</Link><Link className="vx-button vx-outline" href="/resources">More resources</Link></div></article></div></SiteShell>}
