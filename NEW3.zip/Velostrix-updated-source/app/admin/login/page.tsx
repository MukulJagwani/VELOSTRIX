import Link from '@/components/site-link';
import {SiteShell,PageIntro} from '@/components/site-shell';
import {chatGPTSignInPath} from '@/app/chatgpt-auth';
export const metadata={title:'Admin Login',robots:{index:false,follow:false}};
export default function AdminLogin(){return <SiteShell><div className="vx-container vx-page-content"><PageIntro kicker="ADMIN ACCESS" title="Velostrix admin login." description="Sign in with your authorised administrator account to access the admissions and learner workspace."/><section className="vx-panel vx-account-intro"><h2>Secure administrator sign-in</h2><p>Admin access is verified against the authorised Velostrix accounts.</p><div className="vx-button-row"><a className="vx-button" href={chatGPTSignInPath('/admin')} target="_top">Continue with ChatGPT</a><Link className="vx-text-link" href="/learner/login">Go to learner login</Link></div></section></div></SiteShell>}
