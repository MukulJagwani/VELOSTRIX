import Link from '@/components/site-link';
import { requireChatGPTUser } from "../chatgpt-auth";
import { isAdmin } from "@/lib/server";
import AdminDashboard from "./dashboard";
export const dynamic="force-dynamic";
export default async function AdminPage(){
 await requireChatGPTUser("/admin");const user=await isAdmin();
 if(!user)return <main className="access-message"><h1>Admin access required</h1><p>Please sign in with the Velostrix website owner’s account.</p><a className="button" href="/signout-with-chatgpt?return_to=/admin" target="_top">Switch account</a><Link href="/">Back to Velostrix</Link></main>;
 return <AdminDashboard email={user.email}/>;
}
