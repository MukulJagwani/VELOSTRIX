'use client';
export default function LearnerError({reset}:{reset:()=>void}){return <main className="vx-site vx-container vx-error-boundary"><h1>Learner services are temporarily unavailable.</h1><p>Your saved progress is kept in your account. Please try again.</p><button className="vx-button" onClick={reset}>Try again</button></main>}
