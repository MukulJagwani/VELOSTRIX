import {notFound} from 'next/navigation';
import {SiteShell} from '@/components/site-shell';
import {LearnerAuthForm,type AuthMode} from '@/components/learner-auth-form';
import {connections} from '@/lib/server';
import {safeReturnTo} from '@/lib/learner-auth';
export const dynamic='force-dynamic';
export const metadata={title:'Learner Account',robots:{index:false,follow:false},referrer:'no-referrer' as const};
export default async function AccountAction({params,searchParams}:{params:Promise<{action:string}>;searchParams:Promise<{returnTo?:string;token?:string}>}){const {action}=await params;if(!['login','signup','forgot-password','reset-password','verify-email','resend-verification'].includes(action))notFound();const query=await searchParams;return <SiteShell><div className="vx-container vx-account-layout"><LearnerAuthForm mode={action as AuthMode} returnTo={safeReturnTo(query.returnTo)} token={typeof query.token==='string'?query.token:''} emailAvailable={connections().email}/></div></SiteShell>}
