import Link from '@/components/site-link';
import {notFound} from 'next/navigation';
import {SiteShell,PageIntro} from '@/components/site-shell';
import {LearnerAction} from '@/components/learner-actions';
import {requireLearner} from '@/lib/learner-auth';
import {certificationCategory} from '@/lib/certifications';
import {getCertifications} from '@/lib/learning-server';
export const dynamic='force-dynamic';
export const metadata={title:'Save Certification Interest',robots:{index:false,follow:false}};
export default async function InterestPage({searchParams}:{searchParams:Promise<{category?:string;certification?:string}>}){const query=await searchParams;const category=certificationCategory(query.category||'');if(!category)notFound();const params=new URLSearchParams({category:category.id});if(query.certification)params.set('certification',query.certification);const learner=await requireLearner('/learner/interests?'+params);const records=await getCertifications(category.domain);const item=query.certification?records.find(record=>record.id===query.certification&&record.category_id===category.id):null;if(query.certification&&!item)notFound();return <SiteShell><div className="vx-container vx-page-content"><PageIntro kicker="YOUR CERTIFICATION JOURNEY" title={item?.title||category.name} description={item?.description||category.description}/><section className="vx-panel vx-account-intro"><h2>Let’s find your next step.</h2><p>Save this interest to your account. The Velostrix team can use your name and email address to respond with programme details.</p><p><strong>{learner.name}</strong><br/>{learner.email}</p><LearnerAction endpoint="/api/learner/interests" body={{categoryId:category.id,certificationId:item?.id||''}}>Save my interest</LearnerAction><Link className="vx-text-link vx-official-link" href="/learner">View my learning account</Link></section></div></SiteShell>}
