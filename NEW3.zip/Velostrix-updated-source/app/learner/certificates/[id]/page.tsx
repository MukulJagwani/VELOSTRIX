import Link from '@/components/site-link';
import {notFound} from 'next/navigation';
import {Award} from 'lucide-react';
import {SiteShell} from '@/components/site-shell';
import {PrintCertificate} from '@/components/learner-actions';
import {requireLearner} from '@/lib/learner-auth';
import {db} from '@/lib/server';
import type {CompletionCertificate} from '@/lib/learning-server';
export const dynamic='force-dynamic';
export const metadata={title:'Completion Certificate',robots:{index:false,follow:false}};
export default async function CertificatePage({params}:{params:Promise<{id:string}>}){const {id}=await params;const learner=await requireLearner('/learner/certificates/'+id);if(!/^[a-f0-9-]{36}$/.test(id))notFound();const certificate=await db().prepare('SELECT id,course_id,content_version,learner_name,issued_at FROM completion_certificates WHERE id=? AND learner_id=?').bind(id,learner.id).first<CompletionCertificate>();if(!certificate)notFound();return <SiteShell><div className="vx-container vx-page-content vx-certificate-page"><div className="vx-certificate-controls"><Link className="vx-text-link" href="/learner">Back to your learning</Link><PrintCertificate/></div><article className="vx-certificate"><span className="vx-certificate-brand">VELOSTRIX</span><p>ARTIFICIAL INTELLIGENCE + CYBERSECURITY</p><Award size={58} aria-hidden="true"/><h1>Certificate of Completion</h1><p>This confirms that</p><h2>{certificate.learner_name}</h2><p>has completed the Velostrix course</p><h3>Cyber Law</h3><p>Including the required introductory lessons and course knowledge check.</p><dl><dt>Issued</dt><dd>{new Date(certificate.issued_at).toLocaleDateString('en-IN',{day:'numeric',month:'long',year:'numeric',timeZone:'UTC'})}</dd><dt>Certificate ID</dt><dd>{certificate.id}</dd></dl><small>A Velostrix course completion record. This is not an accredited legal or professional qualification.</small></article></div></SiteShell>}
