import { sqliteTable, text, integer, index, uniqueIndex } from "drizzle-orm/sqlite-core";
export const applications = sqliteTable("applications", {
 id:text("id").primaryKey(), name:text("name").notNull(), email:text("email").notNull(), phone:text("phone").notNull(), segment:text("segment").notNull(),
 location:text("location").notNull().default(""), course:text("course").notNull().default("Cyber & AI Security Bootcamp"),
 status:text("status").notNull().default("New"), paymentStatus:text("payment_status").notNull().default("Unpaid"),
 paymentId:text("payment_id"), paymentUrl:text("payment_url"), paymentAttempt:text("payment_attempt"), notificationStatus:text("notification_status").notNull().default("Not configured"),
 createdAt:text("created_at").notNull(), updatedAt:text("updated_at").notNull(),
}, t=>[uniqueIndex("idx_applications_email").on(t.email),index("idx_applications_created").on(t.createdAt),index("idx_applications_status").on(t.status),uniqueIndex("idx_applications_payment").on(t.paymentId)]);
export const policies=sqliteTable("policies",{slug:text("slug").primaryKey(),label:text("label").notNull(),objectKey:text("object_key").notNull(),fileName:text("file_name").notNull(),updatedAt:text("updated_at").notNull()});
export const webhookEvents=sqliteTable("webhook_events",{id:text("id").primaryKey(),createdAt:text("created_at").notNull()});
export const limits=sqliteTable("submission_limits",{key:text("key").primaryKey(),count:integer("count").notNull().default(0),expiresAt:integer("expires_at").notNull()});
export const enquiries=sqliteTable("enquiries",{
 id:text("id").primaryKey(),name:text("name").notNull(),email:text("email").notNull(),phone:text("phone").notNull(),location:text("location").notNull(),course:text("course").notNull(),requestType:text("request_type").notNull(),preferredTime:text("preferred_time").notNull().default(""),message:text("message").notNull().default(""),status:text("status").notNull().default("New"),scheduledAt:text("scheduled_at"),adminNote:text("admin_note").notNull().default(""),notificationStatus:text("notification_status").notNull().default("Not configured"),createdAt:text("created_at").notNull(),updatedAt:text("updated_at").notNull()
},t=>[index("idx_enquiries_created").on(t.createdAt)]);

export const learners=sqliteTable('learners',{
 id:text('id').primaryKey(),name:text('name').notNull(),email:text('email').notNull(),passwordHash:text('password_hash').notNull(),status:text('status').notNull().default('active'),
 emailVerifiedAt:text('email_verified_at'),verificationRequired:integer('verification_required').notNull().default(0),consentAt:text('consent_at').notNull(),consentVersion:text('consent_version').notNull(),createdAt:text('created_at').notNull(),lastLoginAt:text('last_login_at'),
},t=>[uniqueIndex('idx_learners_email').on(t.email),index('idx_learners_created').on(t.createdAt)]);
export const learnerSessions=sqliteTable('learner_sessions',{
 tokenHash:text('token_hash').primaryKey(),learnerId:text('learner_id').notNull().references(()=>learners.id,{onDelete:'cascade'}),createdAt:integer('created_at').notNull(),expiresAt:integer('expires_at').notNull(),lastSeenAt:integer('last_seen_at').notNull(),
},t=>[index('idx_sessions_learner').on(t.learnerId),index('idx_sessions_expiry').on(t.expiresAt)]);
export const learnerTokens=sqliteTable('learner_tokens',{
 tokenHash:text('token_hash').primaryKey(),learnerId:text('learner_id').notNull().references(()=>learners.id,{onDelete:'cascade'}),purpose:text('purpose').notNull(),expiresAt:integer('expires_at').notNull(),createdAt:integer('created_at').notNull(),
},t=>[index('idx_tokens_learner').on(t.learnerId)]);
export const courseEnrollments=sqliteTable('course_enrollments',{
 id:text('id').primaryKey(),learnerId:text('learner_id').notNull().references(()=>learners.id,{onDelete:'cascade'}),courseId:text('course_id').notNull(),contentVersion:text('content_version').notNull(),status:text('status').notNull().default('enrolled'),createdAt:text('created_at').notNull(),completedAt:text('completed_at'),
},t=>[uniqueIndex('idx_enrollment_learner_course').on(t.learnerId,t.courseId)]);
export const lessonProgress=sqliteTable('lesson_progress',{
 id:text('id').primaryKey(),learnerId:text('learner_id').notNull().references(()=>learners.id,{onDelete:'cascade'}),courseId:text('course_id').notNull(),lessonId:text('lesson_id').notNull(),completedAt:text('completed_at').notNull(),
},t=>[uniqueIndex('idx_progress_unique').on(t.learnerId,t.courseId,t.lessonId)]);
export const assessments=sqliteTable('learner_assessments',{
 id:text('id').primaryKey(),learnerId:text('learner_id').notNull().references(()=>learners.id,{onDelete:'cascade'}),courseId:text('course_id').notNull(),score:integer('score').notNull(),passed:integer('passed').notNull(),createdAt:text('created_at').notNull(),
});
export const completionCertificates=sqliteTable('completion_certificates',{
 id:text('id').primaryKey(),learnerId:text('learner_id').notNull().references(()=>learners.id,{onDelete:'cascade'}),courseId:text('course_id').notNull(),contentVersion:text('content_version').notNull(),learnerName:text('learner_name').notNull(),issuedAt:text('issued_at').notNull(),
},t=>[uniqueIndex('idx_certificate_learner_course').on(t.learnerId,t.courseId)]);
export const certifications=sqliteTable('certifications',{
 id:text('id').primaryKey(),title:text('title').notNull(),domain:text('domain').notNull(),categoryId:text('category_id').notNull(),description:text('description').notNull(),level:text('level'),issuer:text('issuer'),sourceUrl:text('source_url'),kind:text('kind').notNull().default('certification'),status:text('status').notNull().default('draft'),displayOrder:integer('display_order').notNull().default(0),authorizationConfirmed:integer('authorization_confirmed').notNull().default(0),updatedAt:text('updated_at').notNull(),updatedBy:text('updated_by').notNull(),
},t=>[index('idx_certifications_catalogue').on(t.domain,t.status,t.displayOrder)]);
export const certificationInterests=sqliteTable('certification_interests',{
 id:text('id').primaryKey(),learnerId:text('learner_id').notNull().references(()=>learners.id,{onDelete:'cascade'}),categoryId:text('category_id').notNull(),certificationId:text('certification_id').notNull().default(''),createdAt:text('created_at').notNull(),
},t=>[uniqueIndex('idx_interest_unique').on(t.learnerId,t.categoryId,t.certificationId)]);
