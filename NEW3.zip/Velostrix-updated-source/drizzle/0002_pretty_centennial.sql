CREATE TABLE `learner_assessments` (
	`id` text PRIMARY KEY NOT NULL,
	`learner_id` text NOT NULL,
	`course_id` text NOT NULL,
	`score` integer NOT NULL,
	`passed` integer NOT NULL,
	`created_at` text NOT NULL,
	FOREIGN KEY (`learner_id`) REFERENCES `learners`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE TABLE `certification_interests` (
	`id` text PRIMARY KEY NOT NULL,
	`learner_id` text NOT NULL,
	`category_id` text NOT NULL,
	`certification_id` text DEFAULT '' NOT NULL,
	`created_at` text NOT NULL,
	FOREIGN KEY (`learner_id`) REFERENCES `learners`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_interest_unique` ON `certification_interests` (`learner_id`,`category_id`,`certification_id`);--> statement-breakpoint
CREATE TABLE `certifications` (
	`id` text PRIMARY KEY NOT NULL,
	`title` text NOT NULL,
	`domain` text NOT NULL,
	`category_id` text NOT NULL,
	`description` text NOT NULL,
	`level` text,
	`issuer` text,
	`source_url` text,
	`kind` text DEFAULT 'certification' NOT NULL,
	`status` text DEFAULT 'draft' NOT NULL,
	`display_order` integer DEFAULT 0 NOT NULL,
	`authorization_confirmed` integer DEFAULT 0 NOT NULL,
	`updated_at` text NOT NULL,
	`updated_by` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_certifications_catalogue` ON `certifications` (`domain`,`status`,`display_order`);--> statement-breakpoint
CREATE TABLE `completion_certificates` (
	`id` text PRIMARY KEY NOT NULL,
	`learner_id` text NOT NULL,
	`course_id` text NOT NULL,
	`content_version` text NOT NULL,
	`learner_name` text NOT NULL,
	`issued_at` text NOT NULL,
	FOREIGN KEY (`learner_id`) REFERENCES `learners`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_certificate_learner_course` ON `completion_certificates` (`learner_id`,`course_id`);--> statement-breakpoint
CREATE TABLE `course_enrollments` (
	`id` text PRIMARY KEY NOT NULL,
	`learner_id` text NOT NULL,
	`course_id` text NOT NULL,
	`content_version` text NOT NULL,
	`status` text DEFAULT 'enrolled' NOT NULL,
	`created_at` text NOT NULL,
	`completed_at` text,
	FOREIGN KEY (`learner_id`) REFERENCES `learners`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_enrollment_learner_course` ON `course_enrollments` (`learner_id`,`course_id`);--> statement-breakpoint
CREATE TABLE `learner_sessions` (
	`token_hash` text PRIMARY KEY NOT NULL,
	`learner_id` text NOT NULL,
	`created_at` integer NOT NULL,
	`expires_at` integer NOT NULL,
	`last_seen_at` integer NOT NULL,
	FOREIGN KEY (`learner_id`) REFERENCES `learners`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `idx_sessions_learner` ON `learner_sessions` (`learner_id`);--> statement-breakpoint
CREATE INDEX `idx_sessions_expiry` ON `learner_sessions` (`expires_at`);--> statement-breakpoint
CREATE TABLE `learner_tokens` (
	`token_hash` text PRIMARY KEY NOT NULL,
	`learner_id` text NOT NULL,
	`purpose` text NOT NULL,
	`expires_at` integer NOT NULL,
	`created_at` integer NOT NULL,
	FOREIGN KEY (`learner_id`) REFERENCES `learners`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `idx_tokens_learner` ON `learner_tokens` (`learner_id`);--> statement-breakpoint
CREATE TABLE `learners` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`email` text NOT NULL,
	`password_hash` text NOT NULL,
	`status` text DEFAULT 'active' NOT NULL,
	`email_verified_at` text,
	`verification_required` integer DEFAULT 0 NOT NULL,
	`consent_at` text NOT NULL,
	`consent_version` text NOT NULL,
	`created_at` text NOT NULL,
	`last_login_at` text
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_learners_email` ON `learners` (`email`);--> statement-breakpoint
CREATE INDEX `idx_learners_created` ON `learners` (`created_at`);--> statement-breakpoint
CREATE TABLE `lesson_progress` (
	`id` text PRIMARY KEY NOT NULL,
	`learner_id` text NOT NULL,
	`course_id` text NOT NULL,
	`lesson_id` text NOT NULL,
	`completed_at` text NOT NULL,
	FOREIGN KEY (`learner_id`) REFERENCES `learners`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_progress_unique` ON `lesson_progress` (`learner_id`,`course_id`,`lesson_id`);