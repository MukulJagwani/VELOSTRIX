CREATE TABLE `enquiries` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`email` text NOT NULL,
	`phone` text NOT NULL,
	`location` text NOT NULL,
	`course` text NOT NULL,
	`request_type` text NOT NULL,
	`preferred_time` text DEFAULT '' NOT NULL,
	`message` text DEFAULT '' NOT NULL,
	`status` text DEFAULT 'New' NOT NULL,
	`scheduled_at` text,
	`admin_note` text DEFAULT '' NOT NULL,
	`notification_status` text DEFAULT 'Not configured' NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_enquiries_created` ON `enquiries` (`created_at`);--> statement-breakpoint
ALTER TABLE `applications` ADD `location` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `applications` ADD `course` text DEFAULT 'Cyber & AI Security Bootcamp' NOT NULL;