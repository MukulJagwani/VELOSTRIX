CREATE TABLE `applications` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`email` text NOT NULL,
	`phone` text NOT NULL,
	`segment` text NOT NULL,
	`status` text DEFAULT 'New' NOT NULL,
	`payment_status` text DEFAULT 'Unpaid' NOT NULL,
	`payment_id` text,
	`payment_url` text,
	`payment_attempt` text,
	`notification_status` text DEFAULT 'Not configured' NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_applications_email` ON `applications` (`email`);--> statement-breakpoint
CREATE INDEX `idx_applications_created` ON `applications` (`created_at`);--> statement-breakpoint
CREATE INDEX `idx_applications_status` ON `applications` (`status`);--> statement-breakpoint
CREATE UNIQUE INDEX `idx_applications_payment` ON `applications` (`payment_id`);--> statement-breakpoint
CREATE TABLE `submission_limits` (
	`key` text PRIMARY KEY NOT NULL,
	`count` integer DEFAULT 0 NOT NULL,
	`expires_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `policies` (
	`slug` text PRIMARY KEY NOT NULL,
	`label` text NOT NULL,
	`object_key` text NOT NULL,
	`file_name` text NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `webhook_events` (
	`id` text PRIMARY KEY NOT NULL,
	`created_at` text NOT NULL
);
